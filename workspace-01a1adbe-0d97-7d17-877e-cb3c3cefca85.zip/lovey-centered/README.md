# Lovey — Centered Layout (only the arrangement changed)

The user supplied a reference profile and asked for **only** its centering and
line rhythm to be copied onto their own profile. Nothing else was touched:

* every `<size>`, `<b>`, `<i>`, `<color=#...>` tag — byte-for-byte identical
* every hex color, every small-cap letter, every symbol, every word
* the original order of the 16 lines

## What changed

1. All 16 lines are centered on **one shared axis of 50 columns**, using real
   `space` characters. Padding is computed as `(WIDTH - line_width) / 2`.
   Line width is measured in columns, weighted by each segment's `<size>`
   relative to the default size (`BASE = 14`), because a size-20 glyph is wider
   than a size-11 one. East-Asian wide characters count as 2 columns.
2. A single **blank line** separates each block, like the reference:
   name → identity block → divider → about block → divider → boundaries →
   quote → footer (kaomoji + bottom divider). 7 blank lines total.
3. No `<align>` anywhere (the game rejects it). No supplementary-plane glyphs.

## Files

| File | Use |
| --- | --- |
| `P-Profile-Centered.txt` | **Main paste-ready code.** Spaces sit before the tags. |
| `P-Profile-Centered-Inside.txt` | Fallback: identical optical centering, but spaces sit *inside* the first tags, in case an editor trims leading whitespace. |
| `P-Profile-Centered-Plain.txt` | Tags stripped — inspect the alignment as plain text. |
| `P-Profile-Centered-Preview.html` | Rendered preview with the user's real colors/sizes + copy/download buttons. |
| `P-Profile-Centered.png` | Raster preview. |
| `build_centered.py` | Generator. Change `BASE`, `MARGIN` or `NUDGE` and re-run. |

## Validation

* 16 content lines + 7 blank lines = 23 lines
* 1,868 raw chars + 22 newlines = **1,890 counted chars**
* 40 `<color>`, 16 `<size>`, 1 `<b>`, 1 `<i>` — all balanced and correctly nested
* 161 leading spaces across 16 lines; no CRLF, no `<align>`, no astral glyphs
* `[visible(line)]` assertion proves the text content did not change

## Limits

1,890 counted chars is fine for the Reborn biography field (16,384) but **exceeds
the status.3dxchat.net/profile-editor 1,000-char limit**. Compressing it would
require removing colors or text, which the user explicitly forbade. If the target
is that editor, use the already-validated 987/1000 game-safe variant in
`/home/user/lovey-sigil-dark/B2-Game-Spaces.txt`, or ask for a compact version.

## Preview-only note

`︱` (U+FE31), `૮` (U+0AEE) and `˶` (U+02F6) are kept verbatim in the pasted
code — they are part of the user's own profile. The sandbox has no font with
those glyphs, so the PNG draws lookalikes (`¦`, `ა`, `˘`) for those three only.
