# -*- coding: utf-8 -*-
"""
Re-center the user's OWN Reborn/profile code using real leading spaces.

NOTHING else is changed: every tag, hex color, size, glyph, small-cap letter,
word and divider is kept byte-for-byte. Only the leading whitespace and the
blank-line rhythm change, following the reference layout the user supplied.

Tunables:
  BASE   = default in-game font size (spaces outside tags render at this size)
  MARGIN = extra columns added to the widest line
  NUDGE  = optional per-line manual correction, keyed by 1-based line number

Outputs:
  P-Profile-Centered.txt        paste-ready code
  P-Profile-Centered-Plain.txt tags stripped, to inspect the alignment
  P-Profile-Centered-Preview.html
  P-Profile-Centered.png
"""
import os, re, json, html, unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = 14
MARGIN = 4
NUDGE = {}
SCALE = 1.3            # preview-only zoom; the pasted code is unaffected

# ---- the user's own lines, verbatim -----------------------------------------
NAME = '<size=20><b><color=#CA8FFA>✦  L ᴏ ᴠ ᴇ ʏ  ✦</color></b></size>'
NOUN = '<size=11><color=#FCF5BB>ɴᴏᴜɴ</color>   <color=#fde2f5>/ˈʟʌᴠ.ɪ/</color></size>'
IDENT = ('<size=14><color=#ff218c>❖ </color><color=#ff218c>Pᴀɴ</color>'
         '<color=#ffd800>sᴇx</color><color=#21b1ff>ᴜᴀʟ</color>'
         '<color=#fde2f5> ︱ </color><color=#ff8af5>Sʜᴇ</color>'
         '<color=#fde2f5> / </color><color=#FFB6C1>ʜᴇʀ</color>'
         '<color=#ff218c> ❖</color></size>')
VIBE = '<size=13><color=#CCCCFF>✧ Sᴏꜰᴛ Sᴏᴜʟ • Cᴏᴢʏ Vɪʙᴇs • A Lɪᴛᴛʟᴇ Mᴏᴏᴅʏ ✧</color></size>'
LANGS = '<size=11><color=#CBC3E3>FA  •  EN</color></size>'
DIV = ('<size=12><color=#CA8FFA>✧</color><color=#FDD7E4>──────────</color>'
       '<color=#CA8FFA> ✦ </color><color=#FDD7E4>──────────</color>'
       '<color=#CA8FFA>✧</color></size>')
ABOUT1 = '<size=14><color=#FFB2D0>❖ Sʜʏ ᴀᴛ ꜰɪʀsᴛ —— Wᴀʀᴍ ᴡɪᴛʜ ᴛʜᴇ Rɪɢʜᴛ Pᴇᴏᴘʟᴇ ❖</color></size>'
ABOUT2 = '<size=14><color=#CCCCFF>❖ Sᴏꜰᴛ, Eᴍᴏᴛɪᴏɴᴀʟ & ᴀ Lɪᴛᴛʟᴇ Mᴏᴏᴅʏ Sᴏᴍᴇᴛɪᴍᴇs ❖</color></size>'
ABOUT3 = '<size=14><color=#CBC3E3>❖ I ᴡᴀɪᴛ ꜰᴏʀ ʏᴏᴜ ᴛᴏ sᴛᴀʀᴛ ᴛʜᴇ ᴄʜᴀᴛ ..! ❖</color></size>'
BOUND1 = '<size=13><color=#ffbde3>♡ Rᴇsᴘᴇᴄᴛ Sᴘᴀᴄᴇ • Kɪɴᴅɴᴇss & Gᴇɴᴜɪɴᴇ Tᴀʟᴋ ♡</color></size>'
BOUND2 = '<size=12><color=#F863B0>✧ Nᴏ Cᴏɴᴛʀᴏʟ • Nᴏ Vɪᴏʟᴇɴᴄᴇ • Nᴏ Hᴜᴍɪʟɪᴀᴛɪᴏɴ ✧</color></size>'
BOUND3 = '<size=12><color=#FFB2D0>✧ Dᴏɴ\'ᴛ Iɢɴᴏʀᴇ Mᴇ • Nᴏ Pᴜsʜʏ Bᴇʜᴀᴠɪᴏʀ ✧</color></size>'
QUOTE = '<i><size=13><color=#fde2f5>"Bᴇ ᴋɪɴᴅ, ʙᴇ ʀᴇᴀʟ & ʟᴇᴛ\'s ᴍᴀᴋᴇ sᴏꜰᴛ ᴍᴇᴍᴏʀɪᴇs..!"</color></size></i>'
KAO = ('<size=22><color=#d8a9fe>૮₍</color><color=#fe62b5>˶</color>'
       '<color=#6697cc>ᴖ</color><color=#ff80bd>☮</color>'
       '<color=#6697cc>ᴖ</color><color=#d8a9fe>₎ა</color></size>')
FOOT = ('<size=12><color=#FDD7E4>──────────</color><color=#CA8FFA> ✧ </color>'
        '<color=#FDD7E4>──────────</color></size>')

# Reference rhythm: one header block, three text blocks split by dividers,
# one quote block, one footer block - separated by single blank lines.
SEQUENCE = [
    NAME, '',
    NOUN, IDENT, VIBE, LANGS, '',
    DIV, '',
    ABOUT1, ABOUT2, ABOUT3, '',
    DIV, '',
    BOUND1, BOUND2, BOUND3, '',
    QUOTE, '',
    KAO, FOOT,
]

TAG = re.compile(r'<([^<>\r\n]{1,256})>')

def segments(line):
    """-> [(text, size, color, bold, italic), ...] in reading order."""
    out, pos, size, color, bold, italic = [], 0, BASE, '#F2F2F7', False, False
    stack = []
    for m in TAG.finditer(line):
        if m.start() > pos:
            out.append((line[pos:m.start()], size, color, bold, italic))
        pos = m.end()
        tag = m.group(1)
        close = re.match(r'^/([a-z]+)$', tag, re.I)
        if close:
            t = close.group(1).lower()
            if t == 'size':
                size = stack.pop() if stack else BASE
            elif t == 'color':
                color = '#F2F2F7'
            elif t == 'b':
                bold = False
            elif t == 'i':
                italic = False
            continue
        opened = re.match(r'^([a-z]+)(?:=(.*))?$', tag, re.I)
        if not opened:
            continue
        t, v = opened.group(1).lower(), (opened.group(2) or '').strip()
        if t == 'size':
            stack.append(size)
            try:
                size = float(re.match(r'^[\d.]+', v).group(0))
            except Exception:
                pass
        elif t == 'color':
            color = v
        elif t == 'b':
            bold = True
        elif t == 'i':
            italic = True
    if pos < len(line):
        out.append((line[pos:], size, color, bold, italic))
    return out

def char_cols(ch):
    w = 2 if unicodedata.east_asian_width(ch) in ('W', 'F') else 1
    return w

def line_cols(line):
    return sum(char_cols(ch) * (sz / BASE) for txt, sz, *_ in segments(line) for ch in txt)

# ---- centering --------------------------------------------------------------
widths = [line_cols(l) for l in SEQUENCE if l]
WIDTH = max(widths) + MARGIN
padded = []
for i, line in enumerate(SEQUENCE, 1):
    if not line:
        padded.append('')
        continue
    pad = max(0, int((WIDTH - line_cols(line)) / 2) + NUDGE.get(i, 0))
    padded.append(' ' * pad + line)

code = '\n'.join(padded)

# ---- validation -------------------------------------------------------------
counted = len(code) + code.count('\n')
assert '<align' not in code.lower(), 'align tag leaked in'
assert not re.search(r'[\U00010000-\U0010FFFF]', code), 'supplementary-plane glyph'
allowed = {'b', 'i', 'u', 's', 'size', 'color', 'mark', 'sup', 'sub'}
stack = []
for m in TAG.finditer(code):
    t = m.group(1)
    cl = re.match(r'^/([a-z]+)$', t, re.I)
    if cl:
        assert stack and stack.pop() == cl.group(1).lower(), 'bad close ' + t
    else:
        op = re.match(r'^([a-z]+)', t, re.I)
        if op and op.group(1).lower() in allowed:
            stack.append(op.group(1).lower())
assert not stack, 'unclosed ' + str(stack)

# byte-for-byte content check: stripping tags+padding must equal the original
def visible(x):
    return TAG.sub('', x).strip()
assert [visible(l) for l in SEQUENCE if l] == [visible(l) for l in padded if l], 'content changed!'

open(os.path.join(HERE, 'P-Profile-Centered.txt'), 'w', encoding='utf8', newline='\n').write(code)
open(os.path.join(HERE, 'P-Profile-Centered-Plain.txt'), 'w', encoding='utf8', newline='\n').write(
    '\n'.join(TAG.sub('', l) for l in padded))

# ---- fallback: spaces INSIDE the first tags --------------------------------
# Some editors trim leading whitespace. This variant puts the identical optical
# padding just after the opening tags, so it survives a trim(). The count is
# rescaled because those spaces render at the line's own <size>, not at BASE.
inside_lines = []
LEAD = re.compile(r'^(?:<[^<>\r\n]{1,256}>)*')
for line in SEQUENCE:
    if not line:
        inside_lines.append('')
        continue
    plain_pad = max(0, int((WIDTH - line_cols(line)) / 2))
    segs = segments(line)
    first_size = segs[0][1] if segs else BASE
    pad_in = int(round(plain_pad * BASE / first_size))
    at = LEAD.match(line).end()
    inside_lines.append(line[:at] + ' ' * pad_in + line[at:])
inside_code = '\n'.join(inside_lines)
assert [visible(l) for l in SEQUENCE if l] == [visible(l) for l in inside_lines if l]
assert '<align' not in inside_code.lower()
open(os.path.join(HERE, 'P-Profile-Centered-Inside.txt'), 'w', encoding='utf8',
     newline='\n').write(inside_code)
print('inside-tag variant counted', len(inside_code) + inside_code.count('\n'))

print('lines', len(padded), '| counted', counted, '| WIDTH', round(WIDTH, 1))
print('leading-space lines', sum(1 for l in padded if l.startswith(' ')))
print('tags', {t: len(re.findall(r'<' + t + r'(?:=[^<>]*)?>', code, re.I)) for t in ('color', 'size', 'b', 'i')})

# ---- HTML preview -----------------------------------------------------------
rows = []
for line in padded:
    if not line:
        rows.append('<div class="row">&nbsp;</div>')
        continue
    lead = len(line) - len(line.lstrip(' '))
    body = ''
    for txt, sz, col, bold, italic in segments(line.lstrip(' ')):
        style = 'color:%s;font-size:%gpx;' % (html.escape(col), sz * SCALE)
        if bold:
            style += 'font-weight:700;'
        if italic:
            style += 'font-style:italic;'
        inner = html.escape(txt).replace(' ', '&nbsp;')
        body += '<span style="%s">%s</span>' % (style, inner)
    rows.append('<div class="row">' + '&nbsp;' * lead + body + '</div>')

html_doc = '''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Lovey — Centered Layout</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#0b0710;color:#fde2f5;
font-family:ui-monospace,"DejaVu Sans Mono","Courier New",monospace;
display:flex;justify-content:center;padding:26px 14px}
.wrap{width:100%;max-width:760px}
h1{font-size:13px;letter-spacing:.34em;text-transform:uppercase;color:#CA8FFA;margin:0 0 4px}
.note{font-size:11px;color:#8b7c98;line-height:1.8;margin:0 0 18px}
.card{background:linear-gradient(160deg,#160d1c,#120a17 55%,#1a0d20);
border:1px solid #4a2c50;border-radius:14px;padding:26px 18px;max-width:__CARDW__px;margin:0 auto;
box-shadow:0 0 60px rgba(202,143,250,.13);overflow-x:auto}
.row{white-space:pre;line-height:1.85;min-height:1.85em;font-size:__ROWFS__px}
.bar{height:2px;background:linear-gradient(90deg,#ff218c,#ffd800,#21b1ff,#CA8FFA);opacity:.75;margin:16px 0}
.meta{display:flex;flex-wrap:wrap;gap:8px;margin:16px 0 0;font-size:11px}
.chip{border:1px solid #4a2c50;border-radius:999px;padding:6px 12px;color:#c9b6d4}
button{background:#2a1730;color:#fde2f5;border:1px solid #CA8FFA;border-radius:8px;
padding:9px 16px;font:inherit;font-size:12px;cursor:pointer;margin:0 8px 8px 0}
button:hover{background:#3d2146}
textarea{width:100%;height:190px;background:#0d0812;color:#e8d5ee;border:1px solid #4a2c50;
border-radius:8px;padding:12px;font:12px/1.6 ui-monospace,monospace;white-space:pre;overflow:auto}
</style></head><body><div class="wrap">
<h1>Lovey · Centered Layout</h1>
<p class="note">Your own colors, sizes, fonts, symbols and words — untouched. Only the
leading spaces and the blank-line rhythm changed. Every line is centered on ONE shared
axis of __WIDTH__ columns using real <b>space</b> characters (no &lt;align&gt;).
Spaces sit <i>before</i> the tags so they all render at the same default size.</p>
<div class="card">__ROWS__</div>
<div class="bar"></div>
<button id="copy">Copy code</button><button id="dl">Download .txt</button>
<div class="meta"><span class="chip">__COUNTED__ counted chars</span>
<span class="chip">no &lt;align&gt;</span><span class="chip">real spaces only</span>
<span class="chip">BMP glyphs only</span><span class="chip">balanced tags</span></div>
<h1 style="margin-top:26px">Paste-ready code</h1>
<textarea id="code" spellcheck="false" readonly>__CODE__</textarea>
<script>
var CODE=__JSON__;
document.getElementById('copy').onclick=function(){var t=document.getElementById('code');t.select();
try{document.execCommand('copy');this.textContent='Copied ✓'}catch(e){this.textContent='Select & copy manually'}};
document.getElementById('dl').onclick=function(){var b=new Blob([CODE],{type:'text/plain;charset=utf-8'});
var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='P-Profile-Centered.txt';a.click();
setTimeout(function(){URL.revokeObjectURL(a.href)},2000)};
</script></div></body></html>'''
html_doc = (html_doc.replace('__WIDTH__', str(round(WIDTH)))
            .replace('__ROWFS__', str(round(BASE * SCALE, 1)))
            .replace('__CARDW__', str(int(WIDTH * 8.4 * SCALE) + 44))
            .replace('__ROWS__', ''.join(rows))
            .replace('__COUNTED__', str(counted))
            .replace('__CODE__', html.escape(code))
            .replace('__JSON__', json.dumps(code, ensure_ascii=False)))
open(os.path.join(HERE, 'P-Profile-Centered-Preview.html'), 'w', encoding='utf8').write(html_doc)

# ---- PNG preview ------------------------------------------------------------
try:
    from PIL import Image, ImageDraw, ImageFont
    mono = '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
    prop = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    prop_b = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
    prop_i = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf'
    import os.path as _op
    if not _op.exists(prop_i):
        prop_i = prop
    SUB = {'\ufe31': '¦', '\u0aee': 'ა', '\u02f6': '˘'}  # preview-only fallbacks
    SW = 8.4 * SCALE
    W, PAD = int(2 * 34 + WIDTH * SW), 34
    lineh = int(30 * SCALE)
    H = PAD * 2 + 46 + lineh * len(padded)
    im = Image.new('RGB', (W, H), '#100a16')
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([8, 8, W - 8, H - 8], radius=14, outline='#4a2c50', width=2)
    d.text((PAD, PAD - 8), 'BIOGRAPHY', font=ImageFont.truetype(prop_b, int(20 * SCALE)), fill='#fde2f5')
    d.line([(PAD, PAD + 24), (W - PAD, PAD + 24)], fill='#CA8FFA', width=2)
    y = PAD + 44
    for line in padded:
        if not line:
            y += lineh
            continue
        lead = len(line) - len(line.lstrip(' '))
        x = PAD + lead * SW
        lead_font = ImageFont.truetype(mono, int(BASE * SCALE))
        for txt, sz, col, bold, italic in segments(line.lstrip(' ')):
            f = ImageFont.truetype(prop_b if bold else prop, max(9, int(sz * SCALE)))
            shown = ''.join(SUB.get(ch, ch) for ch in txt)
            try:
                d.text((x, y), shown, font=f, fill=col)
                x += d.textlength(shown, font=f)
            except Exception:
                x += len(shown) * sz * .6
        y += lineh
    im.save(os.path.join(HERE, 'P-Profile-Centered.png'))
    print('PNG saved', im.size)
except Exception as exc:
    print('PNG skipped:', exc)
