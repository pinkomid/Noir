# Sigil Studio — بستهٔ آمادهٔ دیپلوی روی Vercel

همهچیز **استاتیک و آفلاینه**: یه فایل `index.html` تکصفحهای، بدون بکند، بدون
API key، بدون `fetch`، بدون CDN، بدون فونت/عکس خارجی، بدون آنالیتیکس.
همهٔ دیتا تو `localStorage` مرورگر خودت میمونه و چیزی به سرور فرستاده نمیشه.

```
sigil-vercel/
├── index.html          ← خود اپ (۱۱۸ KB، همهٔ CSS/JS/دیتا داخلشه)
├── favicon.svg         ← آیکون لوکال
├── robots.txt          ← جلوگیری از ایندکس شدن بهصورت پیشفرض
├── package.json        ← بدون هیچ وابستگی
├── build.js            ← کپی فایلها به dist/ (فقط Node خام)
├── server.js           ← سرور لوکال برای تست (بدون وابستگی)
├── vercel.json         ← تنظیمات بیلد + هدرهای امنیتی
├── .vercelignore
├── .gitignore
├── README.md           ← همین فایل
├── source/             ← سورس کامل قابل ویرایش (دیپلوی نمیشه)
└── optional/           ← صفحهٔ پیشنمایش پروفایل (پیشفرض منتشر نمیشه)
```

---

## روش ۱ — سریعترین: Vercel CLI (بدون گیت)

```bash
cd sigil-vercel
npm i -g vercel          # یکبار
vercel                   # دیپلوی آزمایشی → یه لینک preview میده
vercel --prod            # دیپلوی نهایی → your-project.vercel.app
```

وقتی پرسید `Set up and deploy?` → `Y`، `Which scope?` → اکانت خودت،
`Link to existing project?` → `N`، بقیهٔ سؤالها رو Enter بزن
(`vercel.json` همهچی رو تنظیم کرده).

## روش ۲ — از طریق GitHub (رایجترین)

1. پوشهٔ `sigil-vercel` رو یه ریپوی جدید بفرست:
   ```bash
   cd sigil-vercel
   git init && git add . && git commit -m "Sigil Studio"
   git remote add origin https://github.com/<you>/sigil-studio.git
   git push -u origin main
   ```
2. برو https://vercel.com/new → **Import Git Repository** → ریپو رو انتخاب کن.
3. هیچ تنظیمی لازم نیست: `Framework Preset = Other`،
   `Build Command = npm run build`، `Output Directory = dist`
   (همه از `vercel.json` خونده میشن). **Deploy** بزن.
4. از این به بعد هر `git push` اتوماتیک ریدیپلوی میشه.

## روش ۳ — Drag & Drop

تو https://vercel.com/new گزینهٔ دراپ فولدر هست؛ پوشهٔ `sigil-vercel` رو بنداز.
(اگه فقط فشرده داری، اول `sigil-vercel.zip` رو اکسترکت کن، خود zip رو ننداز.)

---

## تست قبل از دیپلوی (لوکال)

```bash
cd sigil-vercel
npm install       # هیچ پکیجی نصب نمیشه، خیلی سریعه
npm run build     # میسازه dist/index.html
npm run dev       # http://localhost:3000
```

همچنین میتونی مستقیم `index.html` رو تو مرورگر باز کنی — چون هیچ درخواست
شبکهای نداره، از `file://` هم کار میکنه.

---

## انتشار صفحهٔ پروفایل (اختیاری، پیشفرض خاموش)

`optional/profile.html` حاوی اطلاعات شخصیه (گرایش، ضمیرها، شخصیت). چون دیپلوی
Vercel **عمومیه**، پیشفرض تو بیلد گنجونده نمیشه. اگه خواستی `/profile` بالا بیاد:

- تو Vercel → **Settings → Environment Variables** →
  `INCLUDE_PROFILE` = `1` → Save → **Redeploy**
- یا لوکال: `INCLUDE_PROFILE=1 npm run build` (ویندوز: `set INCLUDE_PROFILE=1 && npm run build`)

بدون این متغیر، اون فایل فقط تو پوشهٔ `optional/` هست و سرور تحویلش نمیده.
برای ایندکس نشدن کل سایت هم `robots.txt` تنظیم شده؛ اگه خواستی دیده بشه،
خط `Disallow: /` رو پاک کن یا بذار `Allow: /`.

---

## نکات مهم

| موضوع | وضعیت |
| --- | --- |
| Environment Variables | **هیچکدوم لازم نیست** (فقط `INCLUDE_PROFILE` اختیاریه) |
| Node / بیلد | `npm run build` فقط ۳ فایل رو کپی میکنه، ~۰٫۱ ثانیه |
| بکند / دیتابیس / سرور | نداره؛ `server.js` فقط واسه تست لوکاله |
| درخواست شبکهای از مرورگر | صفر (تنها `http://` داخل فایل، namespaceـه SVGـه، درخواست نیست) |
| NSFW / 18+ | گیت سن + رضایت داخل اپ، کاملاً سمت کاربر |
| لینک Share | از URL hash استفاده میکنه، با دامنهٔ Vercel سازگاره |
| Clipboard | روی HTTPS/`vercel.app` بدون مشکل کار میکنه (تو iframe ممکنه بلاک بشه) |
| آپدیت دادن | `index.html` رو عوض کن → `vercel --prod` یا `git push` |
| هزینه | پلن رایگان (Hobby) کاملاً کافیه |

## عیبیابی

- **صفحه سفید اومد** → تو لاگ بیلد ببین `build: dist/index.html ... OK` چاپ شده؛
  اگه نه، `Output Directory` رو دستی `dist` بذار.
- **Vercel گفت framework پیدا نکرد** → طبیعیه؛ `Other` انتخاب کن یا ولش کن،
  `vercel.json` بیلد رو مشخص کرده.
- **فایل `index.html` رو جابجا کردی** → حتماً تو روت پوشه بمونه، `build.js` از اونجا میخونه.
- **خواستی دامنهٔ خودت** → Settings → Domains، نیازی به تغییر کد نیست.

---

## سورس قابل ویرایش

پوشهٔ `source/` (توی دیپلوی نمیاد) شامل `part1.html` + `part2.js` + `data.json`
و `assemble.py`ـه. اگه خواستی اپ رو تغییر بدی:

```bash
cd source
python3 assemble.py            # Sigil-Studio.html رو میسازه
cp Sigil-Studio.html ../index.html
```

`gen_data.py` دیتاست (۱۳ فونت، ۹ پالت، ۸ پرچم، ۲۰۰ قاب، ۲۰ تمپلیت، ۱۸ سؤال) رو
میسازه؛ `00-Decisions.md` تمام تصمیمهای قفلشده و قواعد تأییدشدهٔ ادیتورهاست.

---

## سادهترین حالت ممکن (اگه بیلد نمیخوای)

اگه فقط خواستی یه فایل داشته باشی، کافیه `index.html` رو تنها تو یه پوشه بذاری و
همونجا `vercel` بزنی — کار میکنه. فقط اونوقت `favicon.svg`، `robots.txt` و
هدرهای امنیتی رو نداری، و `package.json`/`build.js`/`vercel.json` رو باید حذف کنی
تا Vercel دنبال `npm run build` نگرده. بستهٔ بالا بهخاطر همین چیزاست که یه بیلد
کوچیک داره.
