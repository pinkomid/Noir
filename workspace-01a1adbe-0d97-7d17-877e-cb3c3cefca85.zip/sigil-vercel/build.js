/* Vercel / local build step. Node only, zero dependencies.
   Copies the static assets into dist/ which Vercel serves. */
const fs = require('fs');
const path = require('path');

const root = __dirname;
const out = path.join(root, 'dist');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

const files = ['index.html', 'favicon.svg', 'robots.txt'];
for (const f of files) {
  const from = path.join(root, f);
  if (!fs.existsSync(from)) throw new Error('missing ' + f);
  fs.copyFileSync(from, path.join(out, f));
}

/* Optional: publish the personal profile preview page at /profile.
   OFF by default for privacy. Set INCLUDE_PROFILE=1 in Vercel's
   Environment Variables to turn it on. */
if (process.env.INCLUDE_PROFILE === '1') {
  const from = path.join(root, 'optional', 'profile.html');
  if (fs.existsSync(from)) {
    fs.mkdirSync(path.join(out, 'profile'), { recursive: true });
    fs.copyFileSync(from, path.join(out, 'profile', 'index.html'));
    console.log('build: profile page included at /profile');
  }
}

const size = fs.statSync(path.join(out, 'index.html')).size;
console.log('build: dist/index.html ' + size + ' bytes — OK');
