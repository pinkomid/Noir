# -*- coding: utf-8 -*-
"""3DXChat-editor-safe biography.
   - NO <align>: centering is done with REAL leading spaces.
   - NO gothic / supplementary-plane fonts: name uses supported small caps.
   - ONLY glyphs present in the editor's own symbol picker + the user's original chars.
   - Only b / i / color / size, balanced and correctly nested, <= 1000 counted chars.
"""
import re, html, os
from collections import Counter

OUT = '/home/user/lovey-sigil-dark'

BLUSH, PINK, ROSE, PLUM, VIOLET = '#E9C4D6', '#D891B2', '#B23A7E', '#9B4FAE', '#8464CE'
BRASS, SOFT, LAV, ICE = '#D9C98F', '#CE93B0', '#A193B4', '#9890C4'
PAN, GOLD, BLUE = '#C2185B', '#C9A227', '#2A6FA8'

# (line, recipe) — recipe is a list of (fragment, hex); fragments MUST concat to the line
ROWS = [
    ('† ╔══ ✦ 666 ✦ ══╗ ‡',
     [('† ╔══ ', BLUSH), ('✦ 666 ✦ ══╗ ‡', VIOLET)]),
    ('« Lᴏᴠᴇʏ »',
     [('« ', ROSE), ('Lᴏᴠᴇʏ »', BLUSH)]),
    ('ɴᴏᴜɴ /ˈʟʌᴠ.ɪ/ • ⁶⁶⁶',
     [('ɴᴏᴜɴ /ˈʟʌᴠ.ɪ/ • ⁶⁶⁶', BRASS)]),
    ('« ᴘᴀɴsᴇxᴜᴀʟ ¦ sʜᴇ / ʜᴇʀ »',
     [('« ᴘᴀɴ', PAN), ('sᴇxᴜᴀʟ ¦ ', GOLD), ('sʜᴇ / ʜᴇʀ »', BLUE)]),
    ('△ • ✟ • ▽',
     [('△ • ✟ • ▽', PLUM)]),
    ('‹ sᴏꜰᴛ › ᴇᴍᴏᴛɪᴏɴᴀʟ • ᴍᴏᴏᴅʏ',
     [('‹ sᴏꜰᴛ ›', ROSE), (' ᴇᴍᴏᴛɪᴏɴᴀʟ • ᴍᴏᴏᴅʏ', SOFT)]),
    ('‹ sʜʏ › ᴡᴀʀᴍ ᴡɪᴛʜ ᴛʜᴇ ʀɪɢʜᴛ ᴏɴᴇs',
     [('‹ sʜʏ ›', VIOLET), (' ᴡᴀʀᴍ ᴡɪᴛʜ ᴛʜᴇ ʀɪɢʜᴛ ᴏɴᴇs', ICE)]),
    ('‹ ʜɪ › ɪ ᴡᴀɪᴛ ꜰᴏʀ ʏᴏᴜ ..!',
     [('‹ ʜɪ ›', PINK), (' ɪ ᴡᴀɪᴛ ꜰᴏʀ ʏᴏᴜ ..!', LAV)]),
    ('♱ ɴᴏ ᴄᴏɴᴛʀᴏʟ • ɴᴏ ᴠɪᴏʟᴇɴᴄᴇ • ɴᴏ ʜᴜᴍɪʟɪᴀᴛɪᴏɴ',
     [('♱ ɴᴏ ᴄᴏɴᴛʀᴏʟ • ɴᴏ ᴠɪᴏʟᴇɴᴄᴇ • ɴᴏ ʜᴜᴍɪʟɪᴀᴛɪᴏɴ', ROSE)]),
    ('† ɴᴏ ɪɢɴᴏʀɪɴɢ • ɴᴏ ᴘᴜsʜʏ ᴇɴᴇʀɢʏ',
     [('† ɴᴏ ɪɢɴᴏʀɪɴɢ • ɴᴏ ᴘᴜsʜʏ ᴇɴᴇʀɢʏ', SOFT)]),
    ('"ʙᴇ ɢᴇɴᴛʟᴇ, ʙᴇ ʀᴇᴀʟ..!"',
     [('"ʙᴇ ɢᴇɴᴛʟᴇ, ʙᴇ ʀᴇᴀʟ..!"', BRASS)]),
    ('‡ ╚══ ✦ ☮ ✦ ══╝ ♱',
     [('‡ ╚══ ', VIOLET), ('✦ ☮ ✦ ══╝ ♱', BLUSH)]),
    ('૮₍˶ᴖ☮ᴖ₎ა',
     [('૮₍˶ᴖ☮', PLUM), ('ᴖ₎ა', BLUE)]),
]

SIZES = {1: 18}               # name only — saves tag characters for the 1000 limit
BOLD = {1}
ITALIC = {10}
BLANK_AFTER = {0, 3, 9}      # real empty lines (each costs 2 counted chars)

WIDTH = max(len(line) for line, _ in ROWS)
parts_out = []
padded_lines = []
for i, (line, recipe) in enumerate(ROWS):
    assert ''.join(f for f, _ in recipe) == line, (i, line)
    body = ''.join('<color=' + c + '>' + f + '</color>' for f, c in recipe)
    if i in SIZES: body = '<size=' + str(SIZES[i]) + '>' + body + '</size>'
    if i in BOLD: body = '<b>' + body + '</b>'
    if i in ITALIC: body = '<i>' + body + '</i>'
    pad = ' ' * ((WIDTH - len(line)) // 2)
    padded_lines.append(pad + body)
    parts_out.append(pad + body)
    if i in BLANK_AFTER: parts_out.append('')

CODE = '\n'.join(parts_out)

# ---------------- validation ----------------
def counted(c): return len(c) + c.count('\n')
assert '<align' not in CODE and '</align' not in CODE
allowed = {'b', 'i', 'color', 'size'}
opens = [m.group(1).lower() for m in re.finditer(r'<([a-zA-Z]+)(?:=[^<>]*)?>', CODE)]
closes = [m.group(1).lower() for m in re.finditer(r'</([a-zA-Z]+)>', CODE)]
assert set(opens) <= allowed and set(closes) <= allowed, (opens, closes)
assert Counter(opens) == Counter(closes), (Counter(opens), Counter(closes))
stack = []
for m in re.finditer(r'<(/)?([a-zA-Z]+)(?:=[^<>]*)?>', CODE):
    closing, tag = m.group(1), m.group(2).lower()
    if closing:
        assert stack and stack[-1] == tag, (tag, stack)
        stack.pop()
    else:
        stack.append(tag)
assert not stack, stack
N = counted(CODE)
assert N <= 1000, N
supp = sorted({ch for ch in CODE if ord(ch) > 0xFFFF})
assert not supp, supp
forbidden = ['⛧', '⛤', '𓆩', '𓆪', '꒰', '꒱', '꒷', '꒦', '⌜', '⌝', '⟦', '⟧',
             '┈', '⁙', '˚', '✞', '☾', '☽', '【', '】', '「', '」', '︱', '𝔏', '𝔬', '𝔳', '𝔢', '𝔶']
assert not [c for c in forbidden if c in CODE], [c for c in forbidden if c in CODE]
# all leading-space centering really present
for i, (line, _) in enumerate(ROWS):
    assert padded_lines[i].startswith(' ' * ((WIDTH - len(line)) // 2))

os.makedirs(OUT, exist_ok=True)
open(OUT + '/B2-Game-Spaces.txt', 'w', encoding='utf-8').write(CODE)
open(OUT + '/B2-Game-Spaces-Plain.txt', 'w', encoding='utf-8').write(
    '\n'.join(' ' * ((WIDTH - len(l)) // 2) + l + ('\n' if i in BLANK_AFTER else '')
              for i, (l, _) in enumerate(ROWS)))

# ---------------- self-contained preview ----------------
def to_html(code):
    out, pos, rx = '', 0, re.compile(r'<([^<>\r\n]{1,256})>')
    def push(t):
        nonlocal out
        out += html.escape(t).replace('\n', '<br>')
    for m in rx.finditer(code):
        push(code[pos:m.start()]); pos = m.end(); p = m.group(1)
        cl = re.match(r'^/([a-z]+)$', p, re.I)
        if cl:
            out += '</' + {'color': 'span', 'size': 'span', 'b': 'strong', 'i': 'em'}[cl.group(1)] + '>'
            continue
        n = re.match(r'^([a-z]+)(?:=(.*))?$', p, re.I)
        if not n: continue
        tag, val = n.group(1).lower(), (n.group(2) or '').strip()
        if tag == 'color': out += '<span style="color:' + html.escape(val) + '">'
        elif tag == 'size': out += '<span style="font-size:' + html.escape(val) + 'px">'
        elif tag == 'b': out += '<strong>'
        elif tag == 'i': out += '<em>'
    push(code[pos:])
    return out

stops = [BLUSH, PINK, ROSE, PLUM, VIOLET, ROSE, PINK, BLUSH]
GRAD = 'linear-gradient(90deg,' + ','.join(stops) + ')'
PAGE = '''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Lovey · Game-safe Biography</title>
<style>
*{box-sizing:border-box}
body{margin:0;padding:24px;background:#07060b;color:#e9e1ef;font:13px/1.6 ui-sans-serif,system-ui,sans-serif;
background:radial-gradient(900px 420px at 50% -8%,rgba(140,35,90,.26),transparent 70%),#07060b}
.wrap{max-width:640px;margin:0 auto}
h1{font-size:18px;letter-spacing:.16em;margin:0 0 4px;background:__GRAD__;-webkit-background-clip:text;background-clip:text;color:transparent}
.k{color:#8d839c;font-size:11px;letter-spacing:.14em;margin-bottom:16px}
.tabs{color:#8d839c;font-size:11px;letter-spacing:.1em;border-bottom:1px solid #2a2032;padding-bottom:8px;margin-bottom:14px}
.tabs b{color:#e9c4d6;border-bottom:2px solid #b23a7e;padding-bottom:8px}
.card{position:relative;background:#100c16;border:1px solid #2a2032;border-radius:14px;padding:20px 22px;overflow:hidden}
.card:before{content:"";position:absolute;inset:0;border-radius:14px;padding:1px;background:__GRAD__;
-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask-composite:exclude;pointer-events:none}
.card h2{margin:0 0 3px;font-size:19px;text-align:right}
.rule{height:2px;background:__GRAD__;margin-bottom:18px;border-radius:2px}
.rich{font:13px/1.9 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;white-space:pre;overflow-x:auto;color:#e9e1ef}
.note{font-size:11px;color:#8d839c;line-height:1.9;margin-top:14px;border-top:1px solid #2a2032;padding-top:12px}
.ok{color:#9fe0b8}.warn{color:#ffb4c8}code{background:#1a1220;padding:1px 5px;border-radius:4px;color:#e9c4d6}
</style></head><body><div class="wrap">
<h1>LOVEY · GAME-SAFE EDITION</h1>
<div class="k">⛧ NO ALIGN · REAL SPACES · SUPPORTED GLYPHS ONLY · __N__ / 1000</div>
<div class="tabs"><b>Profile</b> &nbsp; Gallery 4 &nbsp; Gifts 0 &nbsp; Friends 5</div>
<div class="card"><h2>Biography</h2><div class="rule"></div><div class="rich">__HTML__</div></div>
<div class="note">
<span class="ok">✓</span> No <code>&lt;align&gt;</code> — every line is centered with <b>real leading spaces</b>.<br>
<span class="ok">✓</span> No gothic / supplementary-plane font — the name is <code>« Lᴏᴠᴇʏ »</code> in bold small-caps (your own original characters).<br>
<span class="ok">✓</span> Only <code>&lt;b&gt; &lt;i&gt; &lt;color&gt; &lt;size&gt;</code>, balanced &amp; correctly nested, __N__ / 1000 counted characters.<br>
<span class="ok">✓</span> Only glyphs present in the editor's own symbol picker: <code>† ‡ ♱ ✟ ☮ △ ▽ ✦ ╔ ╗ ╚ ╝ ═ « » ‹ › ¦ • ⁶</code>.<br>
<span class="warn">!</span> Paste with LF line breaks (CRLF counts twice in the editor counter) and <b>keep the leading spaces</b>.<br>
<span class="warn">!</span> The site version (A / A2) still uses <code>&lt;align=center&gt;</code> + gothic <code>𝔏𝔬𝔳𝔢𝔶</code> — that one is for Match3D Reborn only.
</div></div></body></html>'''
PAGE = PAGE.replace('__GRAD__', GRAD).replace('__HTML__', to_html(CODE)).replace('__N__', str(N))
open(OUT + '/B2-Game-Spaces-Preview.html', 'w', encoding='utf-8').write(PAGE)

print('OK counted =', N, '/ 1000   raw =', len(CODE), '  newlines =', CODE.count('\n'))
print('open tags =', dict(Counter(opens)))
print('supplementary chars =', supp)
print('WIDTH =', WIDTH, ' padding spaces =', sum((WIDTH-len(l))//2 for l,_ in ROWS))
print('files: B2-Game-Spaces.txt / B2-Game-Spaces-Plain.txt / B2-Game-Spaces-Preview.html')
