# -*- coding: utf-8 -*-
"""
Rewrite ONLY the descriptive sentences of the user's own profile.

Hard rules (from the user):
  * do NOT touch any color, size, font/glyph style, symbol or SPACE
  * keep the exact line order, blank lines and all tags
  * no sentence may resemble the XYS reference profile
  * replacements must be synonymous, taken from the user's own personality text

Technique: every replacement core has EXACTLY the same character length as the
original core, so the existing leading spaces still center every line perfectly.
Only the characters inside the sentence are swapped - nothing else moves.

Outputs (all in this folder):
  Q-Profile-Reworded.txt            paste-ready code
  Q-Profile-Reworded-Plain.txt     tags stripped
  Q-Profile-Reworded-Preview.html  rendered preview + copy/download
  Q-Profile-Reworded.png           raster preview
  Q-Diff.txt                       old -> new, line by line
"""
import os, re, json, html, unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = open(os.path.join(HERE, 'source.txt'), encoding='utf8').read()

# ---- old core -> new core (identical length) --------------------------------
# line numbers refer to the 1-based lines of source.txt (blank lines included)
PAIRS = {
  7: (
    '✧ Sᴏꜰᴛ Sᴏᴜʟ • Cᴏᴢʏ Vɪʙᴇs • A Lɪᴛᴛʟᴇ Mᴏᴏᴅʏ ✧',
    '✧ Tᴇɴᴅᴇʀ Hᴇᴀʀᴛ • Sʟᴏᴡ Hᴏᴜʀs • Mᴏᴏᴅs Dʀɪꜰᴛ ✧',
    'soft / cosy / a little moody  ->  tender / unhurried / drifting moods',
  ),
  13: (
    '❖ Sʜʏ ᴀᴛ ꜰɪʀsᴛ   ——   Wᴀʀᴍ ᴡɪᴛʜ ᴛʜᴇ Rɪɢʜᴛ Pᴇᴏᴘʟᴇ ❖',
    '❖ Hᴇsɪᴛᴀɴᴛ ᴛᴏ Bᴇɢɪɴ   ——   Oᴘᴇɴ Oɴᴄᴇ I Fᴇᴇʟ Sᴀꜰᴇ ❖',
    'shy at first / warm with the right people  ->  hesitant to begin / opens once safe',
  ),
  15: (
    '❖ Sᴏꜰᴛ, Eᴍᴏᴛɪᴏɴᴀʟ & ᴀ Lɪᴛᴛʟᴇ Mᴏᴏᴅʏ Sᴏᴍᴇᴛɪᴍᴇs ❖',
    '❖ Gᴇɴᴛʟᴇ, Oᴠᴇʀᴛʜɪɴᴋs Iᴛ Aʟʟ & Nᴇᴠᴇʀ Tʜᴇ Sᴀᴍᴇ ❖',
    'soft/emotional/moody  ->  gentle / overthinks / unpredictable (from personality text)',
  ),
  17: (
    '❖ I ᴡᴀɪᴛ ꜰᴏʀ ʏᴏᴜ ᴛᴏ sᴛᴀʀᴛ ᴛʜᴇ ᴄʜᴀᴛ ..! ❖',
    '❖ I Lᴇᴛ Yᴏᴜ Sᴘᴇᴀᴋ Fɪʀsᴛ .. Tʜᴇɴ I Sᴛᴀʏ ❖',
    'waits for others to start the conversation  ->  lets the other person speak first',
  ),
  21: (
    '♡ Rᴇsᴘᴇᴄᴛ Sᴘᴀᴄᴇ • Kɪɴᴅɴᴇss & Gᴇɴᴜɪɴᴇ Tᴀʟᴋ ♡',
    '♡ Rᴏᴏᴍ Tᴏ Bʀᴇᴀᴛʜᴇ • Tʀᴜᴇ Wᴏʀᴅs, Sᴏꜰᴛ Tᴏɴᴇ ♡',
    'respect space / kindness / genuine talk  ->  room to breathe / true words / soft tone',
  ),
  23: (
    '✧ Nᴏ Cᴏɴᴛʀᴏʟ • Nᴏ Vɪᴏʟᴇɴᴄᴇ • Nᴏ Hᴜᴍɪʟɪᴀᴛɪᴏɴ ✧',
    '✧ Cᴏᴍᴍᴀɴᴅs, Cʀᴜᴇʟᴛʏ & Sʜᴀᴍɪɴɢ Hᴀᴠᴇ Nᴏ Pʟᴀᴄᴇ ✧',
    'hates control/violence/humiliation  ->  restructured, no "No A / No B / No C" list',
  ),
  25: (
    "✧ Dᴏɴ'ᴛ Iɢɴᴏʀᴇ Mᴇ • Nᴏ Pᴜsʜʏ Bᴇʜᴀᴠɪᴏʀ ✧",
    '✧ Sɪʟᴇɴᴄᴇ Hᴜʀᴛs Mᴏsᴛ • Nᴏᴛʜɪɴɢ Fᴏʀᴄᴇᴅ ✧',
    'being ignored hurts most / no pushy behaviour  ->  silence hurts / nothing forced',
  ),
  27: (
    '"Bᴇ ᴋɪɴᴅ, ʙᴇ ʀᴇᴀʟ & ʟᴇᴛ\'s ᴍᴀᴋᴇ sᴏꜰᴛ ᴍᴇᴍᴏʀɪᴇs..!"',
    '"Bᴇ Hᴏɴᴇsᴛ, Bᴇ Gᴇɴᴛʟᴇ .. Lɪᴛᴛʟᴇ Mᴏᴍᴇɴᴛs Sᴛᴀʏ..!"',
    'be kind / be real / soft memories  ->  honest / gentle / little moments stay',
  ),
}

lines = SRC.split('\n')
for n, (old, new, note) in PAIRS.items():
    assert len(old) == len(new), (n, len(old), len(new))
    line = lines[n - 1]
    assert line.count(old) == 1, 'old core not found on line %d' % n
    lines[n - 1] = line.replace(old, new)

code = '\n'.join(lines)

# ---- hard validation --------------------------------------------------------
TAG = re.compile(r'<([^<>\r\n]{1,256})>')
assert '<align' not in code.lower()
assert not re.search(r'[\U00010000-\U0010FFFF]', code), 'astral glyph leaked in'
assert '\r' not in code
old_lines, new_lines = SRC.split('\n'), code.split('\n')
assert len(old_lines) == len(new_lines)
for i, (a, b) in enumerate(zip(old_lines, new_lines), 1):
    assert len(a) == len(b), 'line length changed on %d' % i
    # every leading space, every tag and every trailing space must be identical
    assert TAG.findall(a) == TAG.findall(b), 'tags changed on %d' % i
    assert len(a) - len(a.lstrip(' ')) == len(b) - len(b.lstrip(' ')), 'leading spaces %d' % i
    assert len(a) - len(a.rstrip(' ')) == len(b) - len(b.rstrip(' ')), 'trailing spaces %d' % i
    if not a.strip():
        assert not b.strip()
# non-target lines must be byte-for-byte identical
for i, (a, b) in enumerate(zip(old_lines, new_lines), 1):
    if i not in PAIRS:
        assert a == b, 'untouched line changed: %d' % i
# colors & sizes are exactly the same set, in exactly the same order
assert re.findall(r'color=#[0-9a-fA-F]{6}', SRC) == re.findall(r'color=#[0-9a-fA-F]{6}', code)
assert re.findall(r'size=\d+', SRC) == re.findall(r'size=\d+', code)
# tag balance
stack = []
allowed = {'b', 'i', 'u', 's', 'size', 'color', 'mark', 'sup', 'sub'}
for m in TAG.finditer(code):
    t = m.group(1)
    cl = re.match(r'^/([a-z]+)$', t, re.I)
    if cl:
        assert stack and stack.pop() == cl.group(1).lower(), 'bad close ' + t
    else:
        op = re.match(r'^([a-z]+)', t, re.I)
        if op and op.group(1).lower() in allowed:
            stack.append(op.group(1).lower())
assert not stack, 'unclosed ' + str(stack)

# ---- XYS overlap check (small caps folded back to ASCII) --------------------
SMALL = dict(zip('ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ', 'abcdefghijklmnopqrstuvwxyz'))
def fold(s):
    return ''.join(SMALL.get(c, c) for c in s).lower().replace('—', '-')
XYS_PHRASES = [
    'persian-russian', 'quiet soul', 'cozy vibes', 'chill vibes', 'roleplay',
    'hangouts', 'soft spot', 'cute gifts', 'giving & receiving',
    'shy at first', 'warm with the right people', 'right people',
    'respect space', 'kindness', 'genuine talk', 'no drama', 'no toxicity',
    'pushy', 'be yourself', 'beautiful memories', "let's make", 'memories',
    'no control', 'no violence', 'no humiliation', 'be kind', 'be real',
    'warm with', 'quiet soul', 'cozy', 'toxicity', 'drama', 'games',
]
visible = fold(TAG.sub('', code))
found = [p for p in XYS_PHRASES if p in visible]
# 'games' etc. are checked above; only factual labels are allowed to remain
KNOWN_FACT_OVERLAP = []
assert not found or all(f in KNOWN_FACT_OVERLAP for f in found), 'XYS phrase leaked: %s' % found

counted = len(code) + code.count('\n')
open(os.path.join(HERE, 'Q-Profile-Reworded.txt'), 'w', encoding='utf8', newline='\n').write(code)
open(os.path.join(HERE, 'Q-Profile-Reworded-Plain.txt'), 'w', encoding='utf8', newline='\n').write(
    '\n'.join(TAG.sub('', l) for l in new_lines))
with open(os.path.join(HERE, 'Q-Diff.txt'), 'w', encoding='utf8') as f:
    f.write('OLD  ->  NEW   (only these 8 sentences changed; lengths are identical)\n\n')
    for n, (old, new, note) in PAIRS.items():
        f.write('line %02d  len %d -> %d\n' % (n, len(old), len(new)))
        f.write('  OLD: %s\n  NEW: %s\n  MEANING: %s\n\n' % (old, new, note))

print('lines', len(new_lines), '| raw', len(code), '| counted', counted)
print('rewritten', len(PAIRS), '| XYS phrase hits', found)
print('colors', len(re.findall(r'color=#[0-9a-fA-F]{6}', code)),
      '| sizes', len(re.findall(r'size=\d+', code)),
      '| leading spaces', sum(len(l) - len(l.lstrip(' ')) for l in new_lines if l))

# ---- segment parser for the previews ---------------------------------------
def segments(line):
    out, pos, size, color, bold, italic = [], 0, 14, '#F2F2F7', False, False
    stack = []
    for m in TAG.finditer(line):
        if m.start() > pos:
            out.append((line[pos:m.start()], size, color, bold, italic))
        pos = m.end()
        t = m.group(1)
        cl = re.match(r'^/([a-z]+)$', t, re.I)
        if cl:
            k = cl.group(1).lower()
            if k == 'size': size = stack.pop() if stack else 14
            elif k == 'color': color = '#F2F2F7'
            elif k == 'b': bold = False
            elif k == 'i': italic = False
            continue
        op = re.match(r'^([a-z]+)(?:=(.*))?$', t, re.I)
        if not op: continue
        k, v = op.group(1).lower(), (op.group(2) or '').strip()
        if k == 'size':
            stack.append(size)
            mm = re.match(r'^[\d.]+', v)
            if mm: size = float(mm.group(0))
        elif k == 'color': color = v
        elif k == 'b': bold = True
        elif k == 'i': italic = True
    if pos < len(line):
        out.append((line[pos:], size, color, bold, italic))
    return out

# ---- HTML preview -----------------------------------------------------------
SCALE = 1.15
rows = []
for line in new_lines:
    if not line.strip():
        rows.append('<div class="row">&nbsp;</div>'); continue
    body = ''
    for txt, sz, col, bold, italic in segments(line):
        st = 'color:%s;font-size:%gpx;' % (html.escape(col), sz * SCALE)
        if bold: st += 'font-weight:700;'
        if italic: st += 'font-style:italic;'
        body += '<span style="%s">%s</span>' % (st, html.escape(txt).replace(' ', '&nbsp;'))
    rows.append('<div class="row">' + body + '</div>')

doc = '''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Lovey — Reworded</title><style>
*{box-sizing:border-box}body{margin:0;background:#0b0710;color:#fde2f5;
font-family:ui-monospace,"DejaVu Sans Mono","Courier New",monospace;
display:flex;justify-content:center;padding:26px 12px}
.wrap{width:100%;max-width:820px}h1{font-size:13px;letter-spacing:.34em;
text-transform:uppercase;color:#CA8FFA;margin:0 0 6px}
.note{font-size:11px;color:#8b7c98;line-height:1.85;margin:0 0 18px}
.card{background:linear-gradient(170deg,#4a1533 0%,#2c0e26 42%,#170b1e 100%);
border:1px solid #4a2c50;border-radius:12px;padding:26px 16px;
box-shadow:0 0 60px rgba(202,143,250,.12);overflow-x:auto}
.row{white-space:pre;line-height:2.05;min-height:2.05em;font-size:__ROWFS__px}
.bar{height:2px;background:linear-gradient(90deg,#ff218c,#ffd800,#21b1ff,#CA8FFA);
opacity:.7;margin:16px 0}.meta{display:flex;flex-wrap:wrap;gap:8px;margin:14px 0 0;font-size:11px}
.chip{border:1px solid #4a2c50;border-radius:999px;padding:6px 12px;color:#c9b6d4}
button{background:#2a1730;color:#fde2f5;border:1px solid #CA8FFA;border-radius:8px;
padding:9px 16px;font:inherit;font-size:12px;cursor:pointer;margin:0 8px 8px 0}
button:hover{background:#3d2146}textarea{width:100%;height:210px;background:#0d0812;
color:#e8d5ee;border:1px solid #4a2c50;border-radius:8px;padding:12px;
font:12px/1.6 ui-monospace,monospace;white-space:pre;overflow:auto}
h2{font-size:12px;letter-spacing:.2em;color:#CA8FFA;margin:24px 0 8px;text-transform:uppercase}
table{border-collapse:collapse;width:100%;font-size:11px;color:#c9b6d4}
td{border-bottom:1px solid #2d1b33;padding:8px 6px;vertical-align:top}
td.o{color:#8b7c98;text-decoration:line-through;width:46%}td.n{color:#fde2f5}
</style></head><body><div class="wrap"><h1>Lovey · Reworded</h1>
<p class="note">Same colors, same sizes, same small-cap font, same symbols, same
leading spaces, same blank lines, same tag order. Only the 8 descriptive
sentences were swapped for synonymous ones taken from your personality text.
Every replacement has the <b>exact same character length</b>, so the centering
you set is preserved to the pixel. No sentence from the XYS reference remains.</p>
<div class="card">__ROWS__</div><div class="bar"></div>
<button id="copy">Copy code</button><button id="dl">Download .txt</button>
<div class="meta"><span class="chip">__COUNTED__ counted chars</span>
<span class="chip">0 colors changed</span><span class="chip">0 sizes changed</span>
<span class="chip">0 spaces changed</span><span class="chip">0 XYS sentences</span></div>
<h2>Swapped sentences</h2><table>__DIFF__</table>
<h2>Paste-ready code</h2>
<textarea id="code" spellcheck="false" readonly>__CODE__</textarea>
<script>var CODE=__JSON__;
document.getElementById('copy').onclick=function(){var t=document.getElementById('code');
t.select();try{document.execCommand('copy');this.textContent='Copied ✓'}
catch(e){this.textContent='Select & copy manually'}};
document.getElementById('dl').onclick=function(){var b=new Blob([CODE],
{type:'text/plain;charset=utf-8'});var a=document.createElement('a');
a.href=URL.createObjectURL(b);a.download='Q-Profile-Reworded.txt';a.click();
setTimeout(function(){URL.revokeObjectURL(a.href)},2000)};</script>
</div></body></html>'''
diff_rows = ''.join('<tr><td class="o">%s</td><td class="n">%s</td></tr>'
                    % (html.escape(a), html.escape(b)) for a, b, _ in PAIRS.values())
doc = (doc.replace('__ROWFS__', str(round(14 * SCALE, 1)))
       .replace('__ROWS__', ''.join(rows)).replace('__COUNTED__', str(counted))
       .replace('__DIFF__', diff_rows).replace('__CODE__', html.escape(code))
       .replace('__JSON__', json.dumps(code, ensure_ascii=False)))
open(os.path.join(HERE, 'Q-Profile-Reworded-Preview.html'), 'w', encoding='utf8').write(doc)

# ---- PNG preview ------------------------------------------------------------
try:
    from PIL import Image, ImageDraw, ImageFont
    prop = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    bold = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
    SUB = {'\ufe31': '¦', '\u0aee': 'ა', '\u02f6': '˘'}   # preview-only lookalikes
    S, GAP = 1.4, 15
    W = 430
    rows_px = []
    maxw = 0
    for line in new_lines:
        if not line.strip():
            rows_px.append(None); continue
        x = 24
        segs = []
        for txt, sz, col, bo, it in segments(line):
            f = ImageFont.truetype(bold if bo else prop, max(9, int(sz * S)))
            shown = ''.join(SUB.get(c, c) for c in txt)
            w = 0
            try: w = ImageDraw.Draw(Image.new('RGB', (1, 1))).textlength(shown, font=f)
            except Exception: w = len(shown) * sz * .55
            segs.append((x, shown, f, col)); x += w
        rows_px.append(segs); maxw = max(maxw, x)
    W = max(W, int(maxw + 48))
    lh = 38
    H = 24 + 44 + lh * len(rows_px) + 24
    im = Image.new('RGB', (W, H), '#170b1c')
    gd = ImageDraw.Draw(im)
    for yy in range(H):
        t = yy / max(1, H - 1)
        top, bot = (74, 21, 51), (23, 11, 28)
        gd.line([(0, yy), (W, yy)], fill=tuple(int(top[k] + (bot[k] - top[k]) * t) for k in range(3)))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([7, 7, W - 7, H - 7], radius=12, outline='#4a2c50', width=2)
    d.text((24, 16), 'Biography', font=ImageFont.truetype(bold, 20), fill='#fde2f5')
    d.line([(24, 48), (W - 24, 48)], fill='#CA8FFA', width=2)
    y = 58
    for segs in rows_px:
        if segs:
            for x, shown, f, col in segs:
                try: d.text((x, y), shown, font=f, fill=col)
                except Exception: pass
        y += lh
    im.save(os.path.join(HERE, 'Q-Profile-Reworded.png'))
    print('PNG saved', im.size)
except Exception as exc:
    print('PNG skipped:', exc)
