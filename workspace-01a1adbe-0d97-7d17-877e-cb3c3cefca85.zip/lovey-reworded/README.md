# Lovey — Reworded profile (sentences only)

The user pasted their **current** profile code and asked for exactly one thing:
replace the sentences that read like the `XYS` reference profile with different,
synonymous sentences drawn from their own personality text — while leaving
**colors, fonts, spacings, symbols, tags and line order absolutely untouched**.

## What was NOT changed (byte-for-byte assertions)

* all 42 `<color=#...>` values, in the same order — including `#86c0fe`
* all 16 `<size=...>` values, `<b>`, `<i>`
* the small-cap Unicode font style, `✦ ✧ ❖ ♡ • —— ︱`, `ɴᴏᴜɴ`, `/ˈʟʌᴠ.ɪ/`,
  the kaomoji, the 12-dash dividers
* **every single leading space inside the first `<color>` tags** — all 8 lines
  keep the exact indentation the user set
* every blank line (16 content lines, each followed by a blank line)
* the 4 trailing spaces on the `<size=13>` line
* line lengths: each replacement core has the **exact same character count** as
  the original, so the user's hand-tuned centering still lands on the same axis

Validation in `build_reworded.py` asserts all of the above, plus balanced tags,
no `<align>`, no supplementary-plane glyphs, no CRLF, and a folded-lowercase
scan for 30+ XYS phrases (result: **0 hits**).

## The 8 swaps

| # | Old (XYS-like) | New | Same meaning |
| --- | --- | --- | --- |
| 07 | `✧ Sᴏꜰᴛ Sᴏᴜʟ • Cᴏᴢʏ Vɪʙᴇs • A Lɪᴛᴛʟᴇ Mᴏᴏᴅʏ ✧` | `✧ Tᴇɴᴅᴇʀ Hᴇᴀʀᴛ • Sʟᴏᴡ Hᴏᴜʀs • Mᴏᴏᴅs Dʀɪꜰᴛ ✧` | soft / cosy / moody |
| 13 | `❖ Sʜʏ ᴀᴛ ꜰɪʀsᴛ   ——   Wᴀʀᴍ ᴡɪᴛʜ ᴛʜᴇ Rɪɢʜᴛ Pᴇᴏᴘʟᴇ ❖` | `❖ Hᴇsɪᴛᴀɴᴛ ᴛᴏ Bᴇɢɪɴ   ——   Oᴘᴇɴ Oɴᴄᴇ I Fᴇᴇʟ Sᴀꜰᴇ ❖` | shy first, warm once safe |
| 15 | `❖ Sᴏꜰᴛ, Eᴍᴏᴛɪᴏɴᴀʟ & ᴀ Lɪᴛᴛʟᴇ Mᴏᴏᴅʏ Sᴏᴍᴇᴛɪᴍᴇs ❖` | `❖ Gᴇɴᴛʟᴇ, Oᴠᴇʀᴛʜɪɴᴋs Iᴛ Aʟʟ & Nᴇᴠᴇʀ Tʜᴇ Sᴀᴍᴇ ❖` | soft / emotional / moody → adds *overthinking* + *unpredictable* from the personality text |
| 17 | `❖ I ᴡᴀɪᴛ ꜰᴏʀ ʏᴏᴜ ᴛᴏ sᴛᴀʀᴛ ᴛʜᴇ ᴄʜᴀᴛ ..! ❖` | `❖ I Lᴇᴛ Yᴏᴜ Sᴘᴇᴀᴋ Fɪʀsᴛ .. Tʜᴇɴ I Sᴛᴀʏ ❖` | waits for others to start |
| 21 | `♡ Rᴇsᴘᴇᴄᴛ Sᴘᴀᴄᴇ • Kɪɴᴅɴᴇss & Gᴇɴᴜɪɴᴇ Tᴀʟᴋ ♡` | `♡ Rᴏᴏᴍ Tᴏ Bʀᴇᴀᴛʜᴇ • Tʀᴜᴇ Wᴏʀᴅs, Sᴏꜰᴛ Tᴏɴᴇ ♡` | space / kindness / honesty |
| 23 | `✧ Nᴏ Cᴏɴᴛʀᴏʟ • Nᴏ Vɪᴏʟᴇɴᴄᴇ • Nᴏ Hᴜᴍɪʟɪᴀᴛɪᴏɴ ✧` | `✧ Cᴏᴍᴍᴀɴᴅs, Cʀᴜᴇʟᴛʏ & Sʜᴀᴍɪɴɢ Hᴀᴠᴇ Nᴏ Pʟᴀᴄᴇ ✧` | hates control / violence / humiliation; also drops the `No A • No B` list shape that XYS uses |
| 25 | `✧ Dᴏɴ'ᴛ Iɢɴᴏʀᴇ Mᴇ • Nᴏ Pᴜsʜʏ Bᴇʜᴀᴠɪᴏʀ ✧` | `✧ Sɪʟᴇɴᴄᴇ Hᴜʀᴛs Mᴏsᴛ • Nᴏᴛʜɪɴɢ Fᴏʀᴄᴇᴅ ✧` | being ignored hurts most; nothing pushy — removes XYS's literal `Pushy Behavior` |
| 27 | `"Bᴇ ᴋɪɴᴅ, ʙᴇ ʀᴇᴀʟ & ʟᴇᴛ's ᴍᴀᴋᴇ sᴏꜰᴛ ᴍᴇᴍᴏʀɪᴇs..!"` | `"Bᴇ Hᴏɴᴇsᴛ, Bᴇ Gᴇɴᴛʟᴇ .. Lɪᴛᴛʟᴇ Mᴏᴍᴇɴᴛs Sᴛᴀʏ..!"` | kind / real / soft memories — removes XYS's `let's make ... memories` |

XYS phrases explicitly avoided: `Persian–Russian`, `Quiet Soul`, `Cozy Vibes`,
`Chill Vibes`, `Roleplay`, `Games`, `Hangouts`, `Soft spot for cute gifts`,
`Shy at first`, `Warm with the right people`, `Respect Space`,
`Kindness & Genuine Talk`, `No Drama`, `No Toxicity`, `Pushy Behavior`,
`Be yourself`, `beautiful memories`, `No Control / No Violence / No Humiliation`,
`Be kind`, `Be real`.

## Two factual labels left untouched on purpose

`Pᴀɴsᴇxᴜᴀʟ ︱ Sʜᴇ / ʜᴇʀ` and `FA  •  EN` are **identity data, not sentences**.
They coincide with XYS only as facts (orientation, two languages), and changing
them would change the user's identity rather than reword a sentence. Also note:
the personality text the user supplied says `Pᴀɴsᴇxᴜᴀʟ︱Sʜᴇ / Tʜᴇʏ`, while the
pasted profile says `Sʜᴇ / ʜᴇʀ` — the pasted profile was treated as
authoritative. Both can be changed on request, with that line's indentation
re-tuned.

## Files

| File | Use |
| --- | --- |
| `Q-Profile-Reworded.txt` | **paste-ready code** |
| `Q-Profile-Reworded-Plain.txt` | tags stripped |
| `Q-Profile-Reworded-Preview.html` | rendered preview + copy/download + before/after table |
| `Q-Profile-Reworded.png` | raster preview |
| `Q-Diff.txt` | old → new with meanings |
| `source.txt` / `source-escaped.txt` | the user's exact input, kept as the reference |
| `build_reworded.py` | generator with all assertions |

Stats: 2,128 raw chars + 31 newlines = **2,159 counted chars** (Reborn field,
not the 1,000-char status editor). 42 colors, 16 sizes, 0 XYS phrase hits.

Preview-only note: `︱`, `૮`, `˶` have no font in this sandbox, so the PNG draws
`¦`, `ა`, `˘` for those three glyphs. The pasted code keeps them verbatim.
