# Bio Studio — Decisions Log

_Last updated: 2026-11-03. Round 1 answers are LOCKED. Round 2 is pending._

## LOCKED — round 1 (user choices)

| # | Topic | Decision |
|---|-------|----------|
| 1 | Language | **All English** — UI, labels, and generated biography text. No RTL / Persian output. |
| 2 | NSFW | **Full support**, age gate + explicit consent, **100% local** (localStorage only, zero network calls, no analytics, no server storage). |
| 3 | Directness | **Smart** — engine suggests `direct / indirect / omit` per answer from the personality sliders, always user-editable, plus a global override. |
| 4 | Outputs | **Everything** — Match3D Reborn, 3DXChat editor, plain text / Instagram / Discord / X, PNG + SVG card, share link, 3DXChat Gift, HTML/CSS embed, JSON, Markdown. |
| 5 | Library | **Max** — 200 frames, 20 templates, 10 symbol packs, custom frame builder, search / filter / tags / favorites. |
| 6 | Extras | **All** — reverse import, A/B compare, dice + locks, undo/history, pre-copy checklist, presets, one-click game-safe mode, live stats, privacy wipe, offline PWA. |

## VERIFIED technical constraints (from live sources, not guesses)

**match3d.top/reborn — Biography**
- Editor: `textarea rows=12 maxLength=16384`, counter `16384 - about.length`, saved via `PUT /profiles/:id`.
- Rendered by a Unity-style parser (`unity-text-parser-bGgoFKvt.js`) into `.rb-rich-text` / `.rb-biography`, `white-space:pre-wrap`, `overflow-wrap:anywhere`, 13–14px.
- Supported: `<color=#RRGGBB>` or `<color=name>` (lowercase names / 3,4,6,8-digit hex), bare `<#RRGGBB>`, `<size=N>` (1–3 digits, optional decimal/%/px/em; px clamped 8–64), `<b> <i> <u> <s> <sup> <sub>`, `<mark>`, `<align=left|center|right|justified|flush>`, uppercase/lowercase/smallcaps, `<link=http/https …>`. Unknown tags are HTML-escaped, not rendered.
- Newlines -> `<br>`. Input sliced to 65536 before parsing.
- Name `maxLength:32`, title `maxLength:12` (characters page).

**status.3dxchat.net/profile-editor**
- Counter = `profileCode.length + newlineCount`, max **1000** (tags count; CRLF counts twice).
- Only balanced `<b> <i> <color> <size>` are accepted; `var checkHTML` validates open/close, nesting order and unsupported tags. `COLOR` token = lowercase color names or hex, case-insensitive.
- Gift editor: **240 characters / 255 bytes** warning.
- Built-in gradient tool generates per-letter / per-word / per-line / per-paragraph color spans.
- Symbol picker contains `♱ ✟ † ‡ ☮ ╭ ╮ ╰ ╯ ╔ ╗ ╚ ╝ ═ ⊹ ₊ ⁂ ⁶ ✦ ✧ ◈ △ ▽ 「 」 『 』 【 】 〈 〉 « » …` but NOT `⌜ ⌝ ⟦ ⟧ ┈ ⁙ ˚ ☾ ☽ ✞ ⛧ 𓆩 ꒰ 𝔏`. Picker absence is a glyph-risk signal, not a hard rejection.

**Glyph safety (sandbox font coverage + editor picker)**
- Safe almost everywhere: `♱ ✟ ✞ † ‡ ☮ ☾ ☽ △ ▽ ◈ ⊹ ⋆ ₊ ˚ ┈ ┄ ╭ ╮ ╰ ╯ ╔ ╗ ╚ ╝ ✩ ✮ ✶ ✧ ✦ ❖ ♡ ⁂ ⌁ ⟦ ⟧ 「 」 【 】 ⁶ 666`.
- Risky (supplementary planes / rare blocks): `⛧ ⛤ 𓆩 𓆪 ꒰ ꒱ 𖤐 𐂯 𝔏 𝕷 𝒮 ⏤ ⭒ ⚝ ⛓`. Provide auto-substitution and a "BMP-safe" switch.

## Proposed architecture (v1)

Single-page client-side app, no backend, no API keys, no network calls.

```
/questionnaire  -> state: profile {identity, traits[sliders], boundaries, interests, nsfw[], directness}
/style-engine   -> templates (20) + layout config + font set + palette/gradient
/frame-library  -> 200 frames generated combinatorially + custom builder + search/filter/tags/favorites
/symbol-packs   -> 10 packs + kaomoji bank + safety substitution
/renderer       -> Unity-tag renderer + HTML preview renderer (same source of truth)
/exporters      -> Reborn | 3DXChat | Gift | Plain/Social | PNG/SVG | HTML | JSON | MD | share URL
/validators     -> tag balance/order, char counter, glyph check, contrast check, 32/12 length check, pre-copy checklist
/lab            -> reverse import, A/B, dice+locks, undo/history, presets, stats
/storage        -> localStorage profiles + URL-encoded share state + wipe-all + PWA offline
```

Design direction: dark gothic app chrome matching the `Dark Sigil` profile, desktop two-panel (form left / live preview right), mobile tabbed. All English.

## Defaults awaiting round 2 (marked with a star in the question list)

If the user says "just build it", apply: 15 questions · accordion single page · mixed fonts + BMP-safe switch · size presets 11–55 with mobile adaptation · 9 palettes + per-letter/word/line/paragraph/banded/mirrored gradients + image palette extraction + contrast check · 200 combinatorial frames + builder + mix-and-match pairs · all 14 symbol packs · full validator suite · all lab features · gallery in phase 2.

## LOCKED — round 2 (user choices)

| # | Topic | Decision |
|---|-------|----------|
| 7 | Typography | **Per-block font picker** — every block (name, identity, sigil, traits, limits, quote, frames, …) has its own font dropdown; 13 fonts available. |
| 8 | Layout | **Everything** — size presets 11–55 + free slider, all alignments, density, line spacing, blank lines, staircase, dividers, drag-reorderable blocks, dynamic frame width, automatic `<align>`-free variant, name ≤32 / title ≤12 validation. |
| 9 | Colors | **All palettes + exact pride flags** — 9 palettes, 8 gradient modes, 3 directions, image palette extraction, contrast warnings, per-block color overrides, exact hex for pan/bi/trans/ace/lesbian/gay/nonbinary/rainbow. |
| 10 | Frames | **Max** — 200 combinatorial frames + 50-style custom builder + search / tags / favorites + live width preview + matching / split / random pairs. |
| 11 | App UI | **Dark gothic, desktop two-panel** (form left / live preview right), mobile switches to tabs. |
| 12 | Name | **Sigil Studio**. |

## Build status (v1)

- `Sigil-Studio.html` — single self-contained file, 100% client-side, no network, no dependencies. ~105 KB.
- `gen_data.py` / `data.json` — generated data: 200 frames, 20 templates, 18 questions, 13 fonts, 14 symbol packs, 9 palettes, 8 pride flags.
- `part1.html` / `part2.js` — HTML/CSS and JS source parts (assembled by `assemble.py`).
- `default-reborn.txt` / `default-3dxchat.txt` — sample outputs for the default preset.
- `Sigil-Studio-Default.png` — static preview of the default 3DXChat-safe output.
- Validated: `node --check` OK; 20 templates × 9 palettes × 8 gradients × 6 alignments × 20 frames exercised with a DOM stub — 0 failures; Reborn ≤16,384, 3DXChat ≤1,000, Gift ≤240, tags always balanced.

## Known v1 limitations / phase 2

- Public gallery, likes, accounts and cloud sync are phase 2 (they need a backend; v1 is deliberately local-only).
- PNG export draws with system fonts — very exotic supplementary-plane glyphs may fall back; SVG/HTML exports keep the exact characters.
- The in-app preview iframe may block clipboard/downloads; the live preview server and the downloaded file work fully.
- 18 questions are fixed in v1; a question-builder UI (add/edit/reorder questions) is the obvious next addition.

## FIX — game editor align + gothic font (user report, 2026-11-03)

The game editor rejects `<align=center>` and does not render supplementary-plane gothic
(`𝔏𝔬𝔳𝔢𝔶`). Both fixed:

- `renderCode('3dxchat')` now centers every line with **real leading spaces** (the
  `target!=='3dxchat'` exclusion was removed); `<align>` is never emitted.
- The name for game output is forced to `Lᴏᴠᴇʏ` (bold small caps, all BMP).
- Substitution map extended so game output only contains picker glyphs:
  `┈→═ ·→• ˚→° ╭╮╰╯→╔╗╚╝ ︱→¦  「」→«» 【】→‹›`, plus the earlier `⛧→✟ 𓆩→« ꒰→« ⟦→‹ ✞→✟ ☾→✦`.
- Blank lines are skipped for game output (each costs 2 counted chars).
- Default game output: **957 / 1000**; all 20 templates still pass ≤1000.
- Standalone paste-ready version: `lovey-sigil-dark/B2-Game-Spaces.txt`
  (**987 / 1000**, no align, spaces, safe font, safe symbols, balanced tags),
  plus `B2-Game-Spaces-Plain.txt`, `B2-Game-Spaces-Preview.html`,
  `B2-Game-Spaces.png`, and a copy at `bio-studio/game-spaces-sample.txt`.
- `lovey-sigil-dark/Lovey-Sigil-Preview.html` tab B was replaced with this version.
