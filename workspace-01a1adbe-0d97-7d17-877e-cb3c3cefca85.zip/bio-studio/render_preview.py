# -*- coding: utf-8 -*-
"""Render a static PNG preview of a generated biography code file."""
import re, sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter

SRC = '/home/user/bio-studio/default-3dxchat.txt'
OUT = '/home/user/bio-studio/Sigil-Studio-Default.png'
FR = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FB = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

code = open(SRC, encoding='utf-8').read()

def parse(src):
    lines = [[] for _ in src.split('\n')]
    li, stack, pos = 0, [], 0
    def state():
        color, size, bold, ital = '#E9E1EF', 14, False, False
        for tag, val in stack:
            if tag == 'color': color = val
            elif tag == 'size': size = int(val)
            elif tag == 'b': bold = True
            elif tag == 'i': ital = True
        return color, size, bold, ital
    for m in re.finditer(r'<([^<>\r\n]{1,256})>', src):
        for ch in src[pos:m.start()]:
            if ch == '\n': li += 1; continue
            lines[li].append((ch, *state()))
        pos = m.end(); p = m.group(1)
        cl = re.match(r'^/([a-z]+)$', p, re.I)
        if cl:
            tag = cl.group(1).lower()
            for i in range(len(stack)-1, -1, -1):
                if stack[i][0] == tag: del stack[i:]; break
            continue
        n = re.match(r'^([a-z]+)(?:=(.*))?$', p, re.I)
        if n: stack.append((n.group(1).lower(), (n.group(2) or '').strip()))
    for ch in src[pos:]:
        if ch == '\n': li += 1; continue
        lines[li].append((ch, *state()))
    return lines

lines = parse(code)
fonts = {}
def font(size, bold, ital):
    key = (size, bold, ital)
    if key not in fonts: fonts[key] = ImageFont.truetype(FB if bold else FR, max(8, size))
    return fonts[key]

W, TOP, PAD = 520, 30, 26
body = Image.new('RGB', (W, 1400), '#07060B')
glow = Image.new('RGB', (W, 1400), '#07060B')
ImageDraw.Draw(glow).ellipse((-120, -260, W+120, 460), fill=(54, 14, 40))
body = Image.blend(body, glow.filter(ImageFilter.GaussianBlur(150)), .55)
d = ImageDraw.Draw(body)

y = TOP + 62; boxes = []
for ln in lines:
    if not ln: boxes.append((y, 24, None)); y += 24; continue
    mx = max(i[2] for i in ln)
    width = sum(d.textlength(ch, font=font(sz, b, it)) for ch, col, sz, b, it in ln)
    lh = max(26, int(mx * 1.85))
    boxes.append((y, lh, ln, width)); y += lh
card_y1 = y + 34
cx0, cx1 = PAD, W - PAD
stops = [(233,196,214),(216,145,178),(178,58,126),(132,100,206),(178,58,126),(216,145,178),(233,196,214)]

border = Image.new('RGB', (cx1-cx0, card_y1-TOP)); bd = ImageDraw.Draw(border)
for x in range(border.width):
    t = x/(border.width-1); f = t*(len(stops)-1); i = min(int(f), len(stops)-2); a = f-i
    bd.line([(x,0),(x,border.height)], fill=tuple(round(stops[i][k]+(stops[i+1][k]-stops[i][k])*a) for k in range(3)))
body.paste(border, (cx0, TOP))
d = ImageDraw.Draw(body)
d.rounded_rectangle((cx0+2, TOP+2, cx1-2, card_y1-2), radius=12, fill='#100C16')
d.text((cx1-110, card_y1-120), '✞', font=ImageFont.truetype(FR, 130), fill=(36,22,40))
d.text((cx0+24, TOP+22), 'Biography', font=ImageFont.truetype(FB, 19), fill='#FFFFFF')
for x in range(cx0+24, cx1-24):
    t=(x-cx0-24)/max(1,(cx1-cx0-49)); f=t*(len(stops)-1); i=min(int(f),len(stops)-2); a=f-i
    d.line([(x,TOP+52),(x,TOP+54)], fill=tuple(round(stops[i][k]+(stops[i+1][k]-stops[i][k])*a) for k in range(3)))
for box in boxes:
    y0, lh = box[0], box[1]
    if len(box) < 3 or box[2] is None: continue
    ln, width = box[2], box[3]
    x = (W - width)/2; baseline = y0 + int(lh*0.72)
    for ch, col, sz, b, it in ln:
        f = font(sz, b, it)
        d.text((x, baseline), ch, font=f, fill=col, anchor='ls')
        x += d.textlength(ch, font=f)
body = body.crop((0, 0, W, card_y1 + 28))
body.save(OUT)
print('saved', OUT, body.size)
