# Sigil Studio

A fully client-side biography generator for **match3d.top/reborn** and **status.3dxchat.net/profile-editor**.

Open `Sigil-Studio.html` in a browser (or use the live preview server). Nothing is uploaded: no accounts, no API, no analytics, no network requests.

## Tabs

- **BUILD** — 18-question questionnaire (identity, personality sliders, boundaries, optional 18+ NSFW behind an age gate), smart directness (`direct / indirect / omit`, suggested from your sliders but always editable), template picker, per-block font/size/color, alignment, density, spacing, block reordering, palette + gradient + direction, contrast checker, frame pair selector, custom frame builder, symbol packs and kaomoji.
- **LIBRARY** — 200 generated frames with search, tag filters and favorites (click = TOP, Shift-click = BOTTOM, double-click = favorite), 20 templates, 13 font previews, 14 symbol packs and exact pride-flag hexes.
- **LAB** — A/B compare, dice with per-area locks, undo/redo + history, saved presets, JSON import/export, reverse-import an existing bio (parses colors, name, pronouns, quote), re-lock NSFW, wipe all local data.
- **EXPORT** — Reborn code (Unity tags, 16,384), 3DXChat code (b/i/color/size only, 1,000 incl. tags + newlines), Gift (240 chars / 255 bytes), plain text, social, HTML embed, state JSON, Markdown, share link, SVG/PNG card. One-click **Game-safe** strips `<align>`, converts per-letter gradient to color bands and substitutes risky glyphs.
- **HELP** — verified editor limits and safety notes.

## Verified limits

| Target | Limit | Tags |
|---|---|---|
| Reborn Biography | 16,384 chars | color, size, b, i, u, s, sup, sub, mark, align, smallcaps, link, bare hex |
| 3DXChat Profile | 1,000 = length + newlines | b, i, color, size only; balanced & ordered |
| 3DXChat Gift | 240 chars / 255 bytes | b, i, color, size |
| Name / Title | 32 / 12 chars | — |

CRLF counts twice in the 3DXChat counter. `<align>` is NOT supported: game output is centered with real leading spaces, and gothic/supplementary-plane fonts are replaced with supported small caps (`Lᴏᴠᴇʏ`). Its symbol picker supports `♱ ✟ † ‡ ☮ △ ▽ ╔ ╗ ╚ ╝ ⊹ ✦ ⁶` but not `⛧ 𓆩 ꒰ 𝔏`, so those are auto-substituted for game output.

## Keyboard

Ctrl+Z undo · Ctrl+Shift+Z redo · Ctrl+R dice · Ctrl+C copy current output.

## Files

`Sigil-Studio.html` (app) · `gen_data.py` (data generator) · `data.json` (generated data) · `part1.html` + `part2.js` (source parts) · `assemble.py` (build script) · `00-Decisions.md` (locked product decisions) · `default-*.txt` (sample output) · `Sigil-Studio-Default.png` (static preview).
