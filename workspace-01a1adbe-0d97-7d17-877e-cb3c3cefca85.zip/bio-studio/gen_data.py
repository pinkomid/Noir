# -*- coding: utf-8 -*-
import json
UP = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
LO = 'abcdefghijklmnopqrstuvwxyz'

def F(u, l): return {'u': u, 'l': l}
def seq(base, holes=None, count=26):
    holes = holes or {}
    return ''.join(chr(holes.get(i, base + i)) for i in range(count))

GOTH_U = seq(0x1D504, {2:0x212D, 8:0x2111, 17:0x211C, 25:0x2128})
GOTH_L = seq(0x1D51E)
BOLDGOTH_U = seq(0x1D56C); BOLDGOTH_L = seq(0x1D586)
SCRIPT_U = seq(0x1D49C, {1:0x212C,4:0x2130,5:0x2131,7:0x210B,8:0x2110,11:0x2112,12:0x2133,17:0x211B})
SCRIPT_L = seq(0x1D4B6)
DOUBLE_U = seq(0x1D538, {2:0x2102,7:0x210D,13:0x2115,15:0x2119,16:0x211A,17:0x211D,25:0x2124})
DOUBLE_L = seq(0x1D552)
CIRC_U = seq(0x24B6); CIRC_L = seq(0x24D0)
SERIF_U = seq(0x1D400); SERIF_L = seq(0x1D41A)
MONO_U = seq(0x1D670); MONO_L = seq(0x1D68A)
FULL_U = seq(0xFF21); FULL_L = seq(0xFF41)

FONTS = {
 'normal':     F(UP, LO),
 'smallcaps':  F('ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘQʀꜱᴛᴜᴠᴡXʏᴢ', 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ'),
 'gothic':     F(GOTH_U, GOTH_L),
 'boldgothic': F(BOLDGOTH_U, BOLDGOTH_L),
 'script':     F(SCRIPT_U, SCRIPT_L),
 'monospace':  F(MONO_U, MONO_L),
 'serifbold':  F(SERIF_U, SERIF_L),
 'circled':    F(CIRC_U, CIRC_L),
 'double':     F(DOUBLE_U, DOUBLE_L),
 'fullwidth':  F(FULL_U, FULL_L),
 'subscript':  F('ₐᵦ𝒸𝒹ₑ𝒻𝓰ₕᵢⱼₖₗₘₙₒₚQᵣₛₜᵤᵥ𝓌ₓᵧ𝓏','ₐᵦ𝒸𝒹ₑ𝒻𝓰ₕᵢⱼₖₗₘₙₒₚqᵣₛₜᵤᵥ𝓌ₓᵧ𝓏'),
 'italic':     F(UP, LO),
 'lightzalgo': F(UP, LO),
}
FONT_LABELS = ['normal','smallcaps','gothic','boldgothic','script','monospace','serifbold','circled','double','fullwidth','subscript','italic','lightzalgo']
for k,v in FONTS.items():
    assert len(v['u']) == 26 and len(v['l']) == 26, (k, len(v['u']), len(v['l']))

PAL = {
 'bright-pink': ['#FFD9E8','#FFB6C1','#FF8FC8','#F863B0','#E07BCB','#CA8FFA','#F863B0'],
 'dark-gothic': ['#E9C4D6','#D891B2','#B23A7E','#9B4FAE','#8464CE','#B23A7E','#E9C4D6'],
 'rose-gold':   ['#FBE6D8','#F3C9B4','#E7A98F','#D98C78','#C97B6E','#E0A98F','#FBE6D8'],
 'midnight':    ['#C9C6E8','#9E97D6','#7168B8','#4C4694','#332F70','#7168B8','#C9C6E8'],
 'pastel':      ['#FDE6F3','#F7C8E6','#E7C6F5','#C9D8FB','#C9F2E8','#F7C8E6','#FDE6F3'],
 'neon':        ['#FFE9FB','#FF9DEB','#FF4FC3','#B45CFF','#5C7CFF','#FF4FC3','#FFE9FB'],
 'mono':        ['#FFFFFF','#E2E2E2','#C4C4C4','#A0A0A0','#7A7A7A','#C4C4C4','#FFFFFF'],
 'custom':      ['#E9C4D6','#D891B2','#B23A7E','#9B4FAE','#8464CE','#B23A7E','#E9C4D6'],
 'pride-pan':   ['#FFD9E8','#FF218C','#FFD800','#21B1FF','#FF218C','#FFB6C1','#FFD9E8'],
}
PRIDE = {
 'pansexual': ['#FF218C','#FFD800','#21B1FF'],
 'bisexual':  ['#D60270','#9B4F96','#0038A8'],
 'trans':     ['#5BCFFB','#F5ABB9','#FFFFFF'],
 'asexual':   ['#000000','#A3A3A3','#FFFFFF','#800080'],
 'lesbian':   ['#D52D00','#EF7627','#FF9A56','#FFFFFF','#D162A4','#B55690','#A30262'],
 'gay':       ['#078D70','#26CEAA','#98E8C1','#FFFFFF','#7BADE2','#5049CB','#3D1A78'],
 'nonbinary': ['#FCF434','#FFFFFF','#9C59D1','#2C2C2C'],
 'rainbow':   ['#E40303','#FF8C00','#FFED00','#008026','#004DFF','#750787'],
}

CORNERS = [
 ('rounded','╭','╮','╰','╯','┈','⛤','⛧',['cute','bmp']),
 ('double','╔','╗','╚','╝','═','✟','†',['goth','bmp']),
 ('light','┌','┐','└','┘','─','·','·',['minimal','bmp']),
 ('corner','⌜','⌝','⌞','⌟','─','✦','✧',['cute']),
 ('cjk','「','」','「','」','⋯','☾','☽',['cute','bmp']),
 ('egypt','𓆩','𓆪','𓆩','𓆪','⋅','†','‡',['goth','rare']),
 ('dagger','†','‡','‡','†','─','☾','☽',['goth','bmp']),
 ('cross','✟','✟','♱','♱','┈','✞','✞',['goth','bmp']),
 ('moon','☾','☽','☽','☾','·','⋆','⋆',['celestial','bmp']),
 ('star','✦','✦','✧','✧','⋆','✩','✮',['cute','bmp']),
 ('triangle','△','▽','▽','△','·','⛧','⛤',['666','rare']),
 ('wave','︵','︶','︶','︵','~','❀','✿',['floral']),
 ('rune','ᚠ','ᚢ','ᚦ','ᚨ','᛫','ᚱ','ᛉ',['rune']),
 ('goth','♱','✞','✞','♱','╌','†','‡',['goth','bmp']),
 ('minimal','·','·','·','·','─','⊹','⊹',['minimal','bmp']),
 ('bold','▌','▐','▌','▐','━','◆','◇',['minimal','bmp']),
 ('diamond','◆','◆','◇','◇','─','✦','✧',['cute','bmp']),
 ('bracket','⟦','⟧','⟦','⟧','┄','⌜','⌝',['rare']),
 ('cyber','[',']','[',']','=','<','>',['cyber','bmp']),
 ('floral','❀','❀','✿','✿','⋅','♡','♡',['floral','bmp']),
]
MOTIFS = [
 ('666','666',['666']), ('pentagram','⛧',['goth','rare']), ('moons','☾ ☽',['celestial','bmp']),
 ('cross','♱',['goth','bmp']), ('shadowcross','✞',['goth']), ('triangles','△ ▽',['666','bmp']),
 ('sparkle','⊹ ₊˚',['cute']), ('dots','⁙',['rare']), ('peace','☮',['bmp']), ('star','✦',['cute','bmp']),
]
FRAMES = []
for ci,(nm,tl,tr,bl,br,ln,lead,trail,ctags) in enumerate(CORNERS):
    for mi,(mn,mv,mtags) in enumerate(MOTIFS):
        top = f"{lead} {tl}{ln*3} {mv} {ln*3}{tr} {trail}"
        bot = f"{trail} {bl}{ln*3} {mv} {ln*3}{br} {lead}"
        chars = top + bot
        tags = sorted(set(ctags + mtags + [nm, mn] + (['bmp'] if all(ord(c) <= 0xFFFF for c in chars) else ['rare'])))
        FRAMES.append({'id': f'f{ci}_{mi}', 'n': nm, 'm': mn, 'top': top, 'bottom': bot, 'tags': tags})
assert len(FRAMES) == 200

PACKS = {
 'cute':      ['꒰','꒱','꒷','꒦','♡','⋆','₊','˚','⊹','⌜','⌝','✩','✧','❀'],
 'goth':      ['♱','✟','✞','†','‡','☾','☽','⛧','⛤','𓆩','𓆪','⛓','⚝','🜏'],
 '666':       ['666','⁶⁶⁶','△','▽','⛧','⛤','⛥','⛦','🔥','6️⃣'],
 'satanic':   ['⛧','⛤','⛥','⛦','👁','🜏','🜂','🜄','†','♱'],
 'celestial': ['☾','☽','✩','✮','✧','✦','⋆','⭒','☀','✷','⊹'],
 'floral':    ['❀','✿','❁','✾','❃','♡','ꕤ','🌸','⋅'],
 'minimal':   ['·','•','─','━','┈','┄','│','¦','‖','≡','◈'],
 'rune':      ['ᚠ','ᚢ','ᚦ','ᚨ','ᚱ','ᚲ','ᚷ','ᚹ','ᚺ','ᚾ','ᛁ','ᛃ','ᛇ','ᛈ','ᛉ','ᛊ','ᛏ','ᛒ','ᛖ','ᛗ','ᛚ','ᛜ','ᛟ','ᛞ'],
 'kawaii':    ['૮₍˶ᵔ ᵕ ᵔ₎ა','( ˶ˆ ᗜ ˆ˵ )','꒰⑅ᵕ༚ᵕ꒱˖♡','♡⸝⸝','⋆˚✿˖°'],
 'cross':     ['✟','✞','♱','†','‡','☮','⛨','✠'],
 'moon':      ['☾','☽','🌙','✩','⋆','⊹','☼'],
 'triangle':  ['△','▽','◁','▷','◇','◆','⛧','⊿'],
 'kaomoji':   ['૮₍˶ᴖ⛧ᴖ₎ა','૮₍˶ᴖ☮ᴖ₎ა','(͒˃⌂˂͒)','꒰ᐢ. .ᐢ꒱','ᐢ..ᐢ','(｡•́︿•̀｡)'],
 'cyber':     ['[',']','{','}','<','>','/','\\','=','_','#','0','1','▌','▐','░','▒','▓'],
}
KAOMOJIS = PACKS['kawaii'] + ['૮₍˶ᴖ⛧ᴖ₎ა','૮₍˶ᴖ☮ᴖ₎ა','(⛧﹏⛧)','( ˶ˆ ᗜ ˆ˵ )','꒰⑅ᵕ༚ᵕ꒱˖♡']

TEMPLATES = [
 ('sigil','Sigil / Dark Gothic','sigil',['frameTop','name','noun','identity','langs','sigil','traits','limits','quote','frameBottom','kaomoji'],'dark-gothic','gothic','center'),
 ('dictionary','Dictionary','sigil',['name','noun','identity','langs','traits','limits','quote','kaomoji'],'bright-pink','smallcaps','center'),
 ('paragraph','Paragraph / Prose','paragraph',['frameTop','name','prose','quote','frameBottom'],'rose-gold','normal','left'),
 ('minimal','Minimal','minimal',['name','identity','limits','kaomoji'],'mono','smallcaps','center'),
 ('coquette','Coquette','sigil',['frameTop','name','identity','traits','quote','frameBottom','kaomoji'],'pastel','smallcaps','center'),
 ('gothic','Gothic','sigil',['frameTop','name','noun','sigil','traits','limits','quote','frameBottom','kaomoji'],'midnight','gothic','center'),
 ('celestial','Celestial','sigil',['frameTop','name','identity','sigil','traits','quote','frameBottom','kaomoji'],'midnight','serifbold','center'),
 ('dark-academia','Dark Academia','editorial',['name','noun','identity','prose','quote','kaomoji'],'rose-gold','serifbold','left'),
 ('editorial','Editorial','editorial',['name','identity','prose','limits','quote'],'mono','smallcaps','left'),
 ('qa','Q & A','qa',['frameTop','name','qa','frameBottom'],'bright-pink','smallcaps','left'),
 ('terminal','Terminal / Cyber','terminal',['frameTop','name','terminal','frameBottom','kaomoji'],'neon','monospace','left'),
 ('diary','Diary','diary',['frameTop','name','diary','quote','frameBottom','kaomoji'],'pastel','italic','left'),
 ('y2k','Y2K','list',['frameTop','name','identity','list','frameBottom','kaomoji'],'neon','fullwidth','center'),
 ('vaporwave','Vaporwave','list',['frameTop','name','list','quote','frameBottom'],'neon','fullwidth','center'),
 ('royal','Royal','sigil',['frameTop','name','noun','identity','traits','limits','quote','frameBottom'],'rose-gold','serifbold','center'),
 ('witchy','Witchy','sigil',['frameTop','name','sigil','traits','limits','quote','frameBottom','kaomoji'],'midnight','script','center'),
 ('cyber','Cyber','terminal',['frameTop','name','terminal','frameBottom'],'neon','monospace','left'),
 ('list','List / Bullets','list',['frameTop','name','identity','list','limits','frameBottom'],'bright-pink','smallcaps','left'),
 ('quote-first','Quote First','editorial',['quote','name','identity','prose','kaomoji'],'dark-gothic','italic','center'),
 ('name-first','Name First','minimal',['name','identity','sigil','traits','limits','kaomoji'],'dark-gothic','gothic','center'),
]
TEMPLATES = [dict(id=a,label=b,mode=c,blocks=d,palette=e,font=f,align=g) for a,b,c,d,e,f,g in TEMPLATES]
assert len(TEMPLATES) == 20

QUESTIONS = [
 ('name','Display name','text','Lᴏᴠᴇʏ','identity'),
 ('pronouns','Pronouns','chips','Sʜᴇ / ʜᴇʀ','identity',['Sʜᴇ / ʜᴇʀ','ʜᴇ / ʜɪᴍ','Tʜᴇʏ / ᴛʜᴇᴍ','Sʜᴇ / ᴛʜᴇʏ','ᴀɴʏ']),
 ('orient','Orientation','chips','ᴘᴀɴsᴇxᴜᴀʟ','identity',['ᴘᴀɴsᴇxᴜᴀʟ','ʙɪsᴇxᴜᴀʟ','ʟᴇsʙɪᴀɴ','ɢᴀʏ','ᴀsᴇxᴜᴀʟ','ǫᴜᴇᴇʀ']),
 ('noun','Label / noun','text','ɴᴏᴜɴ','identity'),
 ('ipa','Pronunciation','text','/ˈʟʌᴠ.ɪ/','identity'),
 ('langs','Languages','text','FA  ·  EN','identity'),
 ('soft','How soft?','slider',5,'personality'),
 ('shy','How shy?','slider',4,'personality'),
 ('moody','How moody?','slider',3,'personality'),
 ('warm','How warm?','slider',3,'personality'),
 ('who','Who starts the chat?','chips','you','personality',['you','me','either']),
 ('limits','Hard limits','multi','control|violence|humiliation|ignoring|pushy','boundaries',['control','violence','humiliation','ignoring','pushy energy','pressure']),
 ('greens','Green flags','multi','gentle|honest|patient','boundaries',['gentle','honest','patient','soft voice','slow','playful','respectful']),
 ('interests','Interests','text','','personality'),
 ('quote','Signature line','text','ʙᴇ ɢᴇɴᴛʟᴇ, ʙᴇ ʀᴇᴀʟ · ᴍᴀᴋᴇ sᴏꜰᴛ ᴍᴇᴍᴏʀɪᴇs..!','personality'),
 ('mood','Tone / mood','chips','dark','personality',['soft','moody','romantic','gothic','playful','dark']),
 ('fantasies','Fantasies / kinks','multi','','nsfw',['soft dominance','praise','teasing','eye contact','slow burn','aftercare','power play','roleplay','voyeurism','explicit']),
 ('intensity','Explicitness','slider',1,'nsfw'),
]
QUESTIONS = [dict(id=q[0],label=q[1],type=q[2],default=q[3],section=q[4],options=q[5] if len(q)>5 else None) for q in QUESTIONS]

DATA = dict(fonts=FONTS, fontLabels=FONT_LABELS, palettes=PAL, pride=PRIDE, frames=FRAMES,
            packs=PACKS, kaomojis=KAOMOJIS, templates=TEMPLATES, questions=QUESTIONS,
            corners=[c[0] for c in CORNERS], motifs=[m[0] for m in MOTIFS])

open('/home/user/bio-studio/data.json','w',encoding='utf-8').write(json.dumps(DATA, ensure_ascii=False))
print('data.json', len(json.dumps(DATA, ensure_ascii=False)), 'bytes')
print('frames', len(FRAMES), 'templates', len(TEMPLATES), 'questions', len(QUESTIONS), 'fonts', len(FONT_LABELS))
