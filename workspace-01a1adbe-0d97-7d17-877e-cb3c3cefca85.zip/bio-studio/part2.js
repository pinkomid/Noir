function outputs(){
 var R=renderCode('reborn'),G=renderCode('3dxchat'),P=stripTags(R);
 var gift=P.replace(/\n+/g,' ').slice(0,240);
 var html='<div style="background:#100C16;color:#E9E1EF;padding:20px;border-radius:12px;font:14px sans-serif;white-space:pre-wrap">'+unityToHtml(R)+'</div>';
 var json=JSON.stringify(S,null,2);
 var md='# '+S.name+'\n\n**Target:** '+S.target+'\n**Template:** '+tpl().label+'\n**Palette:** '+S.palette+'\n\n```\n'+R+'\n```\n';
 return {reborn:R,'3dxchat':G,gift:gift,plain:P,social:P,html:html,json:json,md:md}
}
function update(){
 var code=renderCode(S.target),h=unityToHtml(code),O=outputs(),st=stats(code),ck=checklist(code);
 var ab=$('abWrap');
 if(ab){var cardA='<div class="card"><h2>Biography</h2><div class="rule"></div><div class="rich" style="line-height:'+S.spacing+'">'+h+'</div></div>';
  if(S.ab&&S.B){var old=S;S=cp(S.B);var h2=unityToHtml(renderCode(S.target));S=old;ab.innerHTML='<div class="ab">'+cardA+'<div class="card"><h2>Biography <span class="mini">B</span></h2><div class="rule"></div><div class="rich" style="line-height:'+S.spacing+'">'+h2+'</div></div></div>'}
  else ab.innerHTML=cardA
 }
 var sHtml='<span>chars <b>'+st.chars+'</b></span><span>tags <b>'+st.tags+'</b></span><span>symbols <b>'+st.syms+'</b></span><span>lines <b>'+st.lines+'</b></span><span>gradient <b>'+st.gradient+'</b></span><span>density <b>'+st.density+'</b></span>';
 if($('stats'))$('stats').innerHTML=sHtml;if($('stats2'))$('stats2').innerHTML=sHtml;
 var cHtml=ck.map(function(x){return '<li><span class="'+(x[0]?'ok':'warn')+'">'+(x[0]?'✓':'!')+'</span> '+esc(x[1])+'</li>'}).join('');
 if($('checklist'))$('checklist').innerHTML=cHtml;if($('checklist2'))$('checklist2').innerHTML=cHtml;if($('checklist3'))$('checklist3').innerHTML=cHtml;
 if($('widthHint')){var ls2=content().filter(function(x){return x.text}).map(function(x){return x.text.length}),mx=Math.max.apply(null,ls2),ft=frameById(S.top).top.length;$('widthHint').innerHTML='Frame width <b>'+ft+'</b> vs longest line <b>'+mx+'</b> → '+(ft>=mx?'frame covers the text ✓':'text is wider than frame (dynamic width '+(S.dynWidth?'on':'off')+')')}
 if($('targetHint'))$('targetHint').innerHTML='Currently exporting <b>'+S.target+'</b>. '+count(code)+' counted characters. '+(S.target==='3dxchat'?'Align stripped, gradient banded, risky glyphs substituted.':'Full per-letter gradient and align kept.');
 if(TAB==='export'){for(var k in O){var e=$('out_'+k);if(e)e.textContent=O[k]}if($('shareBox'))$('shareBox').textContent=shareLink()}
 if($('gateBadge'))$('gateBadge').textContent=(AGEOK&&CONSENT&&S.nsfwOn?'NSFW · local only · no network':'SFW · local only · no network');
 sv('state',S);sv('hist',HIST.slice(-40))
}
function bind(){
 Array.prototype.forEach.call(document.querySelectorAll('[data-bind]'),function(e){
  var handler=function(){setBind(e);if(e.getAttribute('data-bind')==='template'){S.blocks=cp(tpl().blocks);S.palette=tpl().palette;render()}update()};
  e.oninput=handler;e.onchange=handler
 });
 Array.prototype.forEach.call(document.querySelectorAll('[data-chip]'),function(e){e.onclick=function(){var g=e.getAttribute('data-chip'),v=e.getAttribute('data-val'),a=S[g]||[],i=a.indexOf(v);if(i>=0)a.splice(i,1);else a.push(v);S[g]=a;e.className='chip'+(a.indexOf(v)>=0?' on':'');update()}});
 Array.prototype.forEach.call(document.querySelectorAll('[data-single]'),function(e){e.onclick=function(){var g=e.getAttribute('data-single');S[g]=e.getAttribute('data-val');Array.prototype.forEach.call(document.querySelectorAll('[data-single="'+g+'"]'),function(x){x.className='chip'+(x===e?' on':'')});update()}});
 Array.prototype.forEach.call(document.querySelectorAll('[data-font]'),function(e){e.onchange=function(){S.fonts[e.getAttribute('data-font')]=e.value;update()}});
 Array.prototype.forEach.call(document.querySelectorAll('[data-size]'),function(e){e.onchange=function(){S.sizes[e.getAttribute('data-size')]=+e.value;update()}});
 Array.prototype.forEach.call(document.querySelectorAll('[data-color]'),function(e){e.onchange=function(){S.perColor[e.getAttribute('data-color')]=e.value.trim()||null;update()}});
 if($('ageYes'))$('ageYes').onclick=function(){AGEOK=true;CONSENT=true;S.nsfwOn=true;sv('age',true);sv('consent',true);toast('18+ unlocked — local only');render();update()};
 if($('ageNo'))$('ageNo').onclick=function(){S.nsfwOn=false;toast('Staying SFW');render();update()};
 if($('flagApply'))$('flagApply').onclick=function(){var k=$('flagSel').value,f=DATA.pride[k],a=f.concat(f.slice().reverse());while(a.length<7)a.push(f[0]);DATA.palettes.custom=a.slice(0,7);S.palette='custom';toast(k+' palette applied');renderSwatches();update()};
 if($('customApply'))$('customApply').onclick=function(){var a=$('customHex').value.split(',').map(function(x){return x.trim()}).filter(function(x){return /^#[0-9a-fA-F]{6}$/.test(x)});if(a.length<2){toast('need at least 2 hex colors');return}while(a.length<7)a.push(a[a.length-1]);DATA.palettes.custom=a.slice(0,7);S.palette='custom';toast('custom palette applied');renderSwatches();update()};
 if($('imgPick'))$('imgPick').onchange=function(ev){var f=ev.target.files[0];if(!f)return;var r=new FileReader();r.onload=function(){var im=new Image();im.onload=function(){var c=document.createElement('canvas');c.width=40;c.height=40;var x=c.getContext('2d');x.drawImage(im,0,0,40,40);var d=x.getImageData(0,0,40,40).data,buckets={};for(var i=0;i<d.length;i+=16){var key=[Math.round(d[i]/64),Math.round(d[i+1]/64),Math.round(d[i+2]/64)].join(',');if(!buckets[key])buckets[key]=[0,0,0,0];buckets[key][0]+=d[i];buckets[key][1]+=d[i+1];buckets[key][2]+=d[i+2];buckets[key][3]++}var cols=Object.keys(buckets).map(function(k){var b=buckets[k];return rgb2hex([b[0]/b[3],b[1]/b[3],b[2]/b[3]])}).sort(function(a,b){return lum(a)-lum(b)}).slice(0,7);if(cols.length<2){toast('not enough color variety');return}while(cols.length<7)cols.push(cols[cols.length-1]);DATA.palettes.custom=cols;S.palette='custom';if($('imgSw'))$('imgSw').innerHTML=cols.map(function(c){return '<span style="width:26px;height:18px;background:'+c+';border-radius:4px"></span>'}).join('');toast('palette extracted from image');update()};im.src=r.result};r.readAsDataURL(f)};
 if($('randFrame'))$('randFrame').onclick=function(){var f=allFrames();S.top=f[Math.floor(Math.random()*f.length)].id;S.bottom=(S.frameMode==='pair')?S.top:f[Math.floor(Math.random()*f.length)].id;snapshot();render();update()};
 if($('swapFrame'))$('swapFrame').onclick=function(){var t=S.top;S.top=S.bottom;S.bottom=t;render();update()};
 if($('favFrame'))$('favFrame').onclick=function(){var id=S.top,i=S.favorites.indexOf(id);if(i>=0)S.favorites.splice(i,1);else S.favorites.push(id);toast('favorites updated')};
 if($('bBuild'))$('bBuild').onclick=function(){
  var nm=$('bCorner').value,mn=$('bMotif').value,ln=$('bLine').value||'─',rep=Math.max(1,Math.min(8,+$('bRep').value||3)),lead=$('bLead').value||'·',trail=$('bTrail').value||'·';
  var c=DATA.frames.filter(function(f){return f.n===nm})[0]||DATA.frames[0],m=DATA.frames.filter(function(f){return f.m===mn})[0]||DATA.frames[0];
  var ci=DATA.corners.indexOf(nm);if(ci<0)ci=0;var C=[
   ['╭','╮','╰','╯'],['╔','╗','╚','╝'],['┌','┐','└','┘'],['⌜','⌝','⌞','⌟'],['「','」','「','」'],['𓆩','𓆪','𓆩','𓆪'],['†','‡','‡','†'],['✟','✟','♱','♱'],['☾','☽','☽','☾'],['✦','✦','✧','✧'],['△','▽','▽','△'],['︵','︶','︶','︵'],['ᚠ','ᚢ','ᚦ','ᚨ'],['♱','✞','✞','♱'],['·','·','·','·'],['▌','▐','▌','▐'],['◆','◆','◇','◇'],['⟦','⟧','⟦','⟧'],['[',']','[',']'],['❀','❀','✿','✿']][ci];
  var mv=(m.top.split(' ').slice(2,-2).join(' ')||'666');
  var top=lead+' '+C[0]+ln.repeat(rep)+' '+mv+' '+ln.repeat(rep)+C[1]+' '+trail;
  var bot=trail+' '+C[2]+ln.repeat(rep)+' '+mv+' '+ln.repeat(rep)+C[3]+' '+lead;
  var id='c'+S.customFrames.length;S.customFrames.push({id:id,n:'custom-'+nm,m:mn,top:top,bottom:bot,tags:['custom','bmp']});S.top=id;S.bottom=id;snapshot();render();update();toast('custom frame built')
 };
 if($('addSym'))$('addSym').onclick=function(){var v=$('customSym').value.trim();if(v){S.quote=(S.quote+' '+v).trim();render();update()}};
 if($('frameSearch'))$('frameSearch').oninput=function(){S.frameSearch=this.value;renderFrames()};
 if($('clearSearch'))$('clearSearch').onclick=function(){S.frameSearch='';S.frameTags=[];renderTagChips();renderFrames();if($('frameSearch'))$('frameSearch').value=''};
 if($('abOn'))$('abOn').onclick=function(){S.ab=!S.ab;if(S.ab&&!S.B)S.B=cp(S);render();update()};
 if($('useA'))$('useA').onclick=function(){S.ab=0;S.B=null;render();update()};
 if($('useB'))$('useB').onclick=function(){if(S.B){S=cp(S.B);S.B=null;S.ab=0}render();update();toast('B is now the profile')};
 if($('dice'))$('dice').onclick=function(){dice();render();update()};
 if($('undo'))$('undo').onclick=function(){undo()};
 if($('redo'))$('redo').onclick=function(){redo()};
 if($('savePreset'))$('savePreset').onclick=function(){var n=$('presetName').value.trim()||('Preset '+(ls('presets',[]).length+1));var p=ls('presets',[]);p.push({name:n,state:cp(S)});sv('presets',p);toast('preset saved');renderPresets()};
 if($('exportJSON'))$('exportJSON').onclick=function(){$('jsonBox').value=JSON.stringify(S,null,2);copyText($('jsonBox').value)};
 if($('importJSON'))$('importJSON').onclick=function(){try{S=JSON.parse($('jsonBox').value);S.blocks=S.blocks||cp(tpl().blocks);snapshot();render();update();toast('state imported')}catch(e){toast('invalid JSON')}};
 if($('reverseBtn'))$('reverseBtn').onclick=function(){reverseImport($('reverseBox').value)};
 if($('relock'))$('relock').onclick=function(){AGEOK=false;CONSENT=false;S.nsfwOn=false;sv('age',false);sv('consent',false);render();update();toast('NSFW re-locked')};
 if($('wipe'))$('wipe').onclick=function(){if(!confirm('Delete all locally stored profiles, presets and history?'))return;Object.keys(localStorage).filter(function(k){return k.indexOf('sigil.')===0}).forEach(function(k){localStorage.removeItem(k)});S=defState();S.blocks=cp(tpl().blocks);HIST=[];FUT=[];AGEOK=false;CONSENT=false;render();update();toast('all local data wiped')};
 if($('oneSafe'))$('oneSafe').onclick=function(){var c=gameSafe();copyText(c);toast('game-safe code copied ('+count(c)+'/1000)')};
 if($('shareUrl'))$('shareUrl').onclick=function(){copyText(shareLink());toast('share link copied')};
 if($('loadUrl'))$('loadUrl').onclick=function(){var h=location.hash.replace(/^#s=/,'');if(!h){toast('no state in URL');return}try{S=JSON.parse(decodeURIComponent(escape(atob(h))));S.blocks=S.blocks||cp(tpl().blocks);render();update();toast('state loaded from URL')}catch(e){toast('bad share link')}};
 if($('svgBtn'))$('svgBtn').onclick=function(){download('sigil-card.svg',svgCard())};
 if($('pngBtn'))$('pngBtn').onclick=function(){pngCard()};
}
function setBind(e){var p=e.getAttribute('data-bind'),v=e.type==='checkbox'?e.checked:(e.type==='range'||e.type==='number')?+e.value:e.value,a=p.split('.');if(a.length===2){if(!S[a[0]])S[a[0]]={};S[a[0]][a[1]]=v}else S[p]=v}
function snapshot(label){HIST.push({state:cp(S),label:label||'edit',t:new Date().toLocaleTimeString()});if(HIST.length>40)HIST.shift();FUT=[];sv('hist',HIST.slice(-40))}
function undo(){if(!HIST.length){toast('nothing to undo');return}FUT.push(cp(S));S=HIST.pop().state;S.blocks=S.blocks||cp(tpl().blocks);render();update();toast('undo')}
function redo(){if(!FUT.length){toast('nothing to redo');return}HIST.push({state:cp(S),label:'redo',t:new Date().toLocaleTimeString()});S=FUT.pop();render();update();toast('redo')}
function dice(){snapshot('dice');var f=allFrames(),T=DATA.templates,PK=Object.keys(DATA.palettes),G=['per-letter','word','line','banded','mirrored','wave','solid'],FL=DATA.fontLabels;
 if(!S.locks.template){var t=T[Math.floor(Math.random()*T.length)];S.template=t.id;S.blocks=cp(t.blocks);S.palette=t.palette}
 if(!S.locks.palette)S.palette=PK[Math.floor(Math.random()*PK.length)];
 if(!S.locks.gradient)S.gradient=G[Math.floor(Math.random()*G.length)];
 if(!S.locks.frames){S.top=f[Math.floor(Math.random()*f.length)].id;S.bottom=(S.frameMode==='pair')?S.top:f[Math.floor(Math.random()*f.length)].id}
 if(!S.locks.fonts)S.fonts={name:FL[Math.floor(Math.random()*FL.length)]};
 if(!S.locks.symbols){var ks=Object.keys(DATA.packs);S.packs=[ks[Math.floor(Math.random()*ks.length)],ks[Math.floor(Math.random()*ks.length)]]}
 if(S.ab)S.B=cp(S);toast('randomized')
}
function reverseImport(c){if(!c.trim()){toast('paste something first');return}
 var hex=(c.match(/#[0-9a-fA-F]{6}/g)||[]);if(hex.length>=2){var a=[];for(var i=0;i<7;i++)a.push(hex[i%hex.length]);DATA.palettes.custom=a;S.palette='custom'}
 var txt=stripTags(c),lines=txt.split('\n').filter(function(x){return x.trim()});
 if(lines.length){var first=lines[0].trim().replace(/[╭╮╰╯╔╗╚╝┈═─⋆⊹₊˚]/g,'').trim();if(first.length<32)S.name=first}
 if(/she\s*\/\s*her/i.test(txt))S.pronouns='Sʜᴇ / ʜᴇʀ';
 if(/pansexual/i.test(txt))S.orient='ᴘᴀɴsᴇxᴜᴀʟ';
 var q=/"([^"]{4,80})"/.exec(txt);if(q)S.quote=q[1];
 snapshot('reverse import');render();update();toast('bio parsed — form filled')
}
function copyText(t){if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(t).then(function(){toast('copied')},function(){fallbackCopy(t)});else fallbackCopy(t)}
function fallbackCopy(t){var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();try{document.execCommand('copy');toast('copied')}catch(e){toast('copy failed — select manually')}document.body.removeChild(a)}
function download(name,txt){var b=new Blob([txt],{type:'text/plain;charset=utf-8'}),u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(function(){URL.revokeObjectURL(u)},1000);toast('downloaded '+name)}
function shareLink(){try{return location.href.split('#')[0]+'#s='+btoa(unescape(encodeURIComponent(JSON.stringify(S))))}catch(e){return 'state too large for a URL — use JSON export'}}
function svgCard(){var code=renderCode('reborn'),lines=code.split('\n'),w=560,h=120+lines.length*26;
 var s='<svg xmlns="http://www.w3.org/2000/svg" width="'+w+'" height="'+h+'" viewBox="0 0 '+w+' '+h+'"><rect width="100%" height="100%" fill="#100C16"/><rect x="1" y="1" width="'+(w-2)+'" height="'+(h-2)+'" rx="14" fill="none" stroke="#B23A7E" stroke-width="2"/><text x="28" y="42" fill="#FFFFFF" font-family="sans-serif" font-size="19" font-weight="bold">Biography</text><line x1="28" y1="54" x2="'+(w-28)+'" y2="54" stroke="#B23A7E" stroke-width="2"/>';
 var y=84;for(var i=0;i<lines.length;i++){var t=lines[i].replace(/<[^>]*>/g,'');s+='<text x="'+(w/2)+'" y="'+y+'" fill="'+pal()[i%pal().length]+'" font-family="sans-serif" font-size="13" text-anchor="middle">'+esc(t)+'</text>';y+=26}
 return s+'</svg>'}
function pngCard(){var svg=svgCard(),im=new Image(),u=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'}));im.onload=function(){var c=document.createElement('canvas');c.width=im.width;c.height=im.height;c.getContext('2d').drawImage(im,0,0);try{var a=document.createElement('a');a.href=c.toDataURL('image/png');a.download='sigil-card.png';a.click();toast('PNG downloaded')}catch(e){toast('PNG blocked — use SVG')}URL.revokeObjectURL(u)};im.onerror=function(){toast('SVG render failed — use SVG export')};im.src=u}
document.addEventListener('keydown',function(e){if(!(e.ctrlKey||e.metaKey))return;var k=e.key.toLowerCase();if(k==='z'){e.preventDefault();e.shiftKey?redo():undo()}if(k==='r'){e.preventDefault();dice();render();update()}if(k==='c'&&!String(window.getSelection())){e.preventDefault();copyText(renderCode(S.target))}});
(function(){var h=location.hash.replace(/^#s=/,''),shared=null;if(h){try{shared=JSON.parse(decodeURIComponent(escape(atob(h))))}catch(e){shared=null}}init();if(shared){S=shared;S.blocks=S.blocks||cp(tpl().blocks);render();update();toast('shared profile loaded')}})();
</script>
</body>
</html>
