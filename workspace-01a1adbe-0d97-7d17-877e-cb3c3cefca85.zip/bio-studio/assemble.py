# -*- coding: utf-8 -*-
import re
p1=open('/home/user/bio-studio/part1.html',encoding='utf8').read()
p2=open('/home/user/bio-studio/part2.js',encoding='utf8').read()
data=open('/home/user/bio-studio/data.json',encoding='utf8').read()
out=p1.replace('__DATA__',data)+p2
open('/home/user/bio-studio/Sigil-Studio.html','w',encoding='utf8').write(out)
js=re.search(r'<script>(.*?)</script>',out,re.S).group(1)
open('/tmp/sigil_studio.js','w',encoding='utf8').write(js)
print('assembled',len(out),'bytes; js',len(js))
